# Graph路径绑定和上游核验

工程包已经存在并不等于Graph已安装。以下交给代码Agent做，不要求Nick手工改路径。

1. 先读取当前真正的root AGENTS/CLAUDE、现有.codex/graphs registry、当前治理状态来源。以其实际采用情况为准。
2. 记录PACKAGE_ROOT相对REPO_ROOT的位置。没有包含关系或涉及多仓库时，先出明确拓扑方案，不把包目录冒认成Git根。
3. 有既存Graph则增量合并；无则生成候选的root Graph补丁。将 `governance/STATUS.json` 等包路径改写成真实repo相对路径，如 `docs/project-irl/governance/STATUS.json`。运行后只有这一份可变状态。
4. 包内蓝图保留为只读参考，不注册成第二条active lineage。release admission仍关闭。
5. 显示改动路径、来源哈希、registry和AGENTS的增量块。用户已明确授予对应本地文件变更时执行；否则仅出补丁等待该范围授权。不覆盖既存文件或全局配置。
6. 确认实际安装的graph-engineering Skill及版本。使用其当前validate_project_graph.py对真正治理根运行；保存完整命令、退出码、版本、输入hash和报告。不把本包check_package当上游验证结果。
7. 上游validator结构通过后，还须独立语义评审、权限与真实软件验收。安装Skill不自动批准managed execution。

可复制给Codex：
```text
Use the installed graph-engineering skill, if actually available, to evolve the existing Project IRL graph from the v3.1 package blueprint. First bind PACKAGE_ROOT, REPO_ROOT, the adopted governance root, current registry and one canonical STATUS artifact. Preserve existing instructions; show a path-correct, minimal merge plan. Validate with the installed upstream validator. No production/external action is authorized. Do not begin managed execution merely because graph validation passed.
```

本次公开仓库文档可读取，但容器直接clone/download失败，上游validator未在此环境运行。目标Agent必须补做，不许填PASS。
