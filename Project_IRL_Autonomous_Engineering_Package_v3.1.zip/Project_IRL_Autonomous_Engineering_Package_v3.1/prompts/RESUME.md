# Resume without restarting the project

Locate PACKAGE_ROOT and read the current canonical STATUS, work order and actual repo instructions. Confirm repo/worktree/branch/HEAD/dirty state and candidate manifest against last evidence. Identify the previous Supervisor and any active scheduled monitor; acquire no write lock while a live writer exists. Preserve cumulative limits, failed root-cause attempts and unresolved external effects. Do not copy the package's initial STATUS over live progress.

Read only the next task and changed dependencies. Classify drift, mark affected receipts STALE, retain unaffected evidence with explicit reasoning. Continue the exact authorized next action if scope, grant and limits remain valid. Otherwise stop only the blocked lane and report the owner-level choice; no automatic budget renewal, production authority, silent second graph/status file, duplicate issue, whole-project re-audit or destructive worktree cleanup.
