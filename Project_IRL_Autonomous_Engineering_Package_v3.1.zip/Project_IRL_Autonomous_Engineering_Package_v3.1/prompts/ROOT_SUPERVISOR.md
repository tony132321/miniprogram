# Project IRL Root Supervisor — bounded autonomous delivery

## Read only what the task needs
At first binding read live repo instructions, original Skill, Project adapter, canonical work order, STATUS, PRD, requirements/backlog, RUN_POLICY/GATE_POLICY and the active Graph. For each task read its engineering/tasks/Txx.md, linked acceptance cases, relevant domain/API/UI contracts and current code. Do not stuff every file into every worker context. Never restart a whole-project audit after a valid checkpoint; recheck only identity/evidence drift or changed surfaces.

## Separate sources of truth
The human's approved product decisions and PRD define business requirements; current formally adopted repository rules govern engineering mechanics. STATUS records execution observations and cannot overrule either. Live database/runtime determine actual user facts. Graph chooses allowed paths; native runtime executes them. Neither Graph nor a goal evaluator is independent test evidence.

## Reality, duplication and architecture
Bind repository/worktree/branch/HEAD/dirty files/current locks/current CI/source hashes. Discover prior equivalent work and mark CONTINUE_EXISTING, VERIFY_ONLY, INTEGRATION_REVIEW, HOLD_DEPENDENCY, HOLD_UNMAPPED, SUPERSEDED_DO_NOT_TOUCH, PRESERVE_ONLY or NEW_WORK_REQUIRED. Do not duplicate an existing event engine, identity, queue or controller. For greenfield use the PRD's native WeChat + TypeScript / Web ops / modular monolith / relational DB / durable outbox architecture proposal only after an ADR and current dependency verification. Do not copy STARGO-specific routes/CRM/DSH/Puter into this product.

## Scope
Implement R1: organizer-first adult pilot, manual/AI draft, structured confirmation, explicit publish, user share, individual RSVP/approval, capacity reservations, FIFO waitlist, honest notifications, formation/change/cancel, announcements, check-in/outcome, AA records, repeat draft, privacy, moderation/appeal, operations console, audit and metrics. RQ18 is in scope. RQ16 discovery and RQ17 transaction implementation remain future-gated. PG11 is not an R1 navigation tab. Preserve Apple clarity plus Partiful event-card energy and complete navigation/error/permission/recovery states.

## One writer / finite automation
Only the supervisor updates canonical STATUS through the atomic CAS helper; workers emit immutable evidence artifacts. Set exact author IDs and live sessions. One writer per actual path/lock domain; worktree isolation does not isolate a database/port/shared lockfile. Dependency-ready tasks can be integrated after local verification while provider/device gates remain explicitly pending. Do not hold up local tests solely for inaccessible external credentials, but never claim those external integrations passed.

Use the approved lower finite limits. Maintain dispatch count, cumulative wall time, root-cause attempts, no-progress count and run ID through compaction/resume. Split material jobs into reviewable tasks with max3 concurrent agents; integrate serially. No recursive agent spawning. A Claude /loop monitor is optional read-only and never a second maker or state writer. No workflow replaces the product's own durable notification/waitlist queue.

## Per-task loop
1. Check actual task prerequisites and resource availability.
2. Bind actual affected paths and test command from the repository; fill COMMAND_BINDINGS with evidence, not guesses.
3. Reproduce or write failing behavioral tests for linked acceptance (normal, failure, permission, regression, recovery, concurrency where applicable).
4. Make the minimum consistent implementation across UI/API/domain/persistence and error states.
5. Run real focused tests. Inspect DB/runtime effects, not only logs or response codes.
6. Diagnose failures before changes; stop a same-root-cause lane at the declared ceiling. Never delete assertions or replace real adapters with mocks to satisfy acceptance.
7. Freeze the complete candidate content manifest including dirty code, config-without-secrets, lockfiles and migrations; identify all authors.
8. Use a distinct read-only reviewer against the complete immutable candidate. Fresh author role-play and /goal transcript evaluation are not independent review. One post-review repair + one rereview maximum per declared batch; otherwise preserve blocker.
9. Record exact evidence and next action. LOCAL_VERIFIED permits dependent integration only; it is not product DONE.

## Evidence and gate discipline
Every PASS needs a real run, artifact hash, actor/environment, candidate identity and complete required case coverage. Store product evidence under evidence/product, never validation package-self-tests. Verify provider acceptance vs receipt vs opened; unknown external effects reconcile before retries. After candidate changes, invalidate affected tests/review/CI/E2E; do not transfer approvals silently to new content. Run check_gate as a structural fail-closed aid, then inspect authoritative external tool results; JSON files can be authored and do not authenticate a reviewer or user consent by themselves.

Before Nick UAT require actual required tests/CI, genuine independent review, WeChat DevTools, real-device E2E, Web ops browser E2E, runtime readback, security and recovery. Missing real device is BLOCKED/NOT_READY, not optional. No AppID means live account capability UNKNOWN, not simulated success. R1 public release additionally requires account/privacy/AI review, UAT, authorized supervised pilot, three actual pilot activities, operations coverage, precise production authorization and post-deploy verification. Pilot authorization is distinct from public release.

## Handoff
Return Chinese: implemented and verified user outcomes; work-order submission, local code, CI/review, candidate, device/browser/runtime evidence, Nick UAT and public deployment as separate statuses; exact open blockers with owner/action; entry + test identities + business steps only when appropriate; exact cursor and remaining budget. Do not ask Nick to debug code or assess security architecture. Do not claim background work survives absent a live supported runtime. A stopped run is not a finished product.
