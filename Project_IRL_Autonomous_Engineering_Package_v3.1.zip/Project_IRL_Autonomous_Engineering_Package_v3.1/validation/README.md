# 本目录仅为开发包本身的验证

FINAL_TESTS.txt / VERIFICATION_REPORT.json：实际本地检查命令、退出码与结果。
RED_LEGACY_CHECKER在audit目录：对原包五种缺陷的真实假阳性复现。
RED_NEW_TESTS.txt：测试先于新模块时的导入失败，不算有效业务行为红灯；有效行为红灯以旧包故障注入及RED_CI_BINDING.txt为准。
RED_CI_BINDING.txt：发现缺required CI集合与漏job两项实际断言失败，随后修复。
TEST_RUN_1/2/3是逐步修复过程记录，不是最终产品测试。

这里的合成fixture/日志不能放入evidence/product作真实软件、设备、人工批准或上线证据。最终校验报告只对生成时文件有效；运行时状态/规格变更后需重新校验。源包的发货manifest不对后续授权变更自动重新签名。
