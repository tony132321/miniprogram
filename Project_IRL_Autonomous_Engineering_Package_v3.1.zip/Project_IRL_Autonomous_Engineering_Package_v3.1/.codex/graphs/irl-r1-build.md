---
schema: graph-engineering/v1
profile: reviewed-batch/v1
id: irl-r1-build
family: irl-r1-delivery
lineage: irl-r1-delivery
successor_ordinal: 1
status: draft
---

# Project IRL R1 reviewed delivery graph

## Intent

Deliver the authorized, organizer-first R1 code candidate from the immutable PRD, preserving capacity, consent, privacy and truthful notification invariants. A terminal blocked run is not a completed product. Full product acceptance includes real WeChat and Web evidence, not just code or Graph validation.

## Scope

One verified product repository and one PACKAGE_ROOT state source. Inspect existing instructions and code before editing. Reversible local implementation and isolated synthetic-data tests only after explicit scoped grant; no public deployment, real user notification, paid provider traffic, secrets or production database work are executed by this graph.

External side effects: internal-reversible

## Risk and Outcome Contract

Workflow lifetime: durable

Reversibility: reversible

Actual authority effect: none

Material batch: yes

Canonical status artifact: governance/STATUS.json

Business gate: r1-candidate-functional-acceptance

Business state before: approved-r1-behavior-not-verified

Business state after: in-scope-user-journey-evidence-backed-or-explicitly-blocked

Business artifact: evidence/product/terminal-result.json

## State

| Key | Owner | Artifact / provenance | Retention |
| --- | --- | --- | --- |
| binding | Supervisor | governance/STATUS.json repo + command/source receipts | Project policy |
| candidate | Supervisor | immutable code/config/schema manifest and author IDs | Candidate lifetime |
| review | Independent reviewer | read-only findings bound to full candidate identity | Project policy |
| cursor | Supervisor only | governance/STATUS.json task cursor and cumulative budgets | Project lifetime |
| terminal_record | Supervisor | evidence/product/terminal-result.json | Project policy |

## Nodes

| ID | Type | Inputs | Outputs | Evaluator | Loop / exit | Subgraph target | Side effect |
| --- | --- | --- | --- | --- | --- | --- | --- |
| preflight | tool | PACKAGE_ROOT, REPO_ROOT, source baselines | verified identity and scope gaps | actual instructions, commands, existing work and capability evidence recorded | one bounded discovery; stop on ambiguous identity | None | none |
| authorize | human gate | exact project, R1 scope and run limits | matching grant or blocked record | explicit human scope and finite budget; existing valid grant may be reused | no inferred authorization; stop if missing | None | none |
| select | tool | task DAG, current status, resource locks | disjoint ready batch or stop reason | prerequisites implemented for integration, independent resource locks and budget remain | dispatch_count<=120; wall_minutes<=240; on_exhaust=stop | None | none |
| delivery | composite loop | current batch contract, exact paths and failing tests | frozen candidate, independent review, accepted or blocked batch receipt | real tests and independent immutable-candidate review | maker->reviewer->maker; attempts<=1; on_exhaust=stop | None | internal-reversible |
| evaluate | tool | candidate receipts and gate policy | evidence gaps and exact next action | stage gate checks plus actual tool readback; no self-asserted PASS | one evaluation; missing environment blocks that lane | None | none |
| terminal | tool | cursor, tested candidate, blocking gate and budgets | truthful terminal record and preserved resume point | no claim beyond evidence, no secret content | exactly one terminal per managed run | None | internal-reversible |

## Execution Routing

| Node / role | Executor | Minimum tier | Default tier | Reasoning floor | Difficulty signals / selection | Tools / authority | Fallback / escalation |
| --- | --- | --- | --- | --- | --- | --- | --- |
| delivery.maker | dynamic:implementer | balanced | balanced | medium | Raise for ambiguity, cross-module state or concurrency | access=scoped-write; exact approved files and isolated tests | raise_to=deep; on_unavailable=stop |
| delivery.reviewer | dynamic:independent-reviewer | deep | deep | high | Security, consent, evidence drift, final candidate | access=read-only; complete immutable diff and criteria | on_unavailable=stop |

## Edges

| From | To | Guard | Context | Budget / escalation |
| --- | --- | --- | --- | --- |
| START | preflight | package opened in target workspace | current scope, minimal identity | bounded discovery only |
| preflight | authorize | identity and project boundaries verified | scope, limits, authority gaps | one owner request only if unresolved |
| preflight | terminal | identity ambiguous or inaccessible | exact blocker and evidence | stop affected run |
| authorize | select | human_approval=granted | exact scoped grant and approved limits | never exceed grant |
| authorize | terminal | human_approval!=granted | missing or denied grant | stop without product writes |
| select | delivery | ready batch disjoint and within budget | selected tasks, artifact hashes, locks | maximum three agents; one writer per domain |
| select | terminal | no authorized ready work or budget exhausted | completion state or exact blockers | stop, not automatic renewal |
| delivery | evaluate | writers terminal and review recorded | complete candidate and tests/review evidence | at most one post-review repair and one rereview |
| evaluate | select | safe independent ready work remains and budgets allow | status revision, released locks, next cursor | cumulative dispatch<=120; wall_minutes<=240; no_progress<=3 |
| evaluate | terminal | gates satisfied or all remaining work externally blocked or repair exhausted | exact tested scope and residual gates | do not mark blocked product complete |
| terminal | END | terminal_record=written | immutable summary and exact resume cursor | stop without deploy |

## Execution Policy

| Setting | Value |
| --- | --- |
| Model catalog source | Current orchestration surface; otherwise explicit user confirmation |
| Maximum parallel subagents | 3 |
| Maximum delegation depth | 1 |
| Ultra policy | disabled |
| Nested delegation policy | disabled |
| Merge policy | Supervisor freezes one candidate and integrates serially within local authority only |

Declared numbers are proposed ceilings; use the lower of declared and actually approved limits. They are not production grants or completion time estimates. The implementation TDD loop has at most three same-root-cause repairs, distinct from the one permitted post-review repair. All counters persist across sessions and model switches.

## Review Policy

Review role: delivery.reviewer

Review unit: complete immutable batch

Review barrier: all_writers_terminal_or_candidate_frozen

Maximum repair attempts: 1

Terminal record: accepted_or_blocked_with_candidate_identity

## Execution

Use native runtime subagents only when their actual tool support is verified. Never simulate independent review with the author's own role-play. Select tasks by DAG, not numeric order. Local verification permits dependent integration work but does not close live-device/provider gates. The Supervisor is the sole state writer and the Claude interval monitor is read-only. No production authority is delegated.

## Governance

Repository topology: single-repository

Governance root: .

This is a PACKAGE_ROOT-relative blueprint. Before actual installation, bind the real governance root and rewrite artifact paths without creating a second status ledger. Apply current repository instructions, the original work-order Skill and the Project IRL adapter. External or irreversible actions require a separately designed, approved authority-critical contract or the existing formally adopted release workflow. Do not promote this reviewed-batch Graph into production authority.
