# Graph registry — package blueprints

| ID | File | Status | Profile | Canonical status |
| --- | --- | --- | --- | --- |
| irl-r1-build | irl-r1-build.md | draft | reviewed-batch/v1 | governance/STATUS.json |

Only one build graph is registered. The old, incomplete release sketch has been replaced by `roadmap/RELEASE_ADMISSION.md`; it is not an executable authority-critical graph.
Bind paths via `prompts/GRAPH_BINDING.md` before installing into a real repository. Local structural checks do not assert the upstream validator passed.
