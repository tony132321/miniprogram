# Project IRL v3.0 → v3.1 开发包审查报告

**审查日期：2026-09-25。结论：原包存在会让Agent误判完成、丢需求或停在执行入口的实质缺陷。v3.1修复包层面缺口，但没有把小程序开发/上架伪装成已完成。**

## 一、审查对象与证据

读取并核对原ZIP全部32文件，与原PRD v1.0、stargo-work-order v1.1.0及已确认Apple+Partiful页面方向逐项比较。原archive SHA-256：`383d586c7c9b29fcf43331c3638453d78ba1ee24f1b87f77c9f993cef9e13fcd`。完整文件inventory/hash和五次故障注入结果见`audit/V3_AUDIT_EVIDENCE.json`。原PRD及Skill在新旧包中均保持原始字节一致。

原包：35个任务、8条验收定义、35个未解析验收ID。这三个计数含义不同：不是“35个任务全部错误”，也不是“35条用例跑失败”，而是验收引用没有真实规格可执行。

## 二、可复现的假阳性

|输入|旧checker实际结果|合理结果|
|---|---|---|
|原始包未定义验收引用|exit 0 / PACKAGE CHECK: PASS|拒绝|
|把验收JSON改为非法文本|exit 0 / PACKAGE CHECK: PASS|拒绝|
|任务依赖引入T01→T35循环|exit 0 / PACKAGE CHECK: PASS|拒绝|
|无candidate/receipt却写UAT/PASS|exit 0 / PACKAGE CHECK: PASS|拒绝|
|删除整个原release图|exit 0 / PACKAGE CHECK: PASS|拒绝|

这说明旧PASS只能代表它检查的极少路径存在，不能代表交付包完整。原始执行记录保留在`audit/RED_LEGACY_CHECKER.txt`；未改动原ZIP。

## 三、逐项发现与修复

P0/P1/P2为本次包质量优先级，不假冒目标仓库的真实Issue标签。

|ID|优先级|原包定位|实际发现|v3.1处理|
|---|---|---|---|---|
| F01 | P0 | specs/acceptance_cases.json / engineering/backlog.json | 35个任务仅8条已定义验收，引用35个未定义验收ID。 | 保留8个旧ID并补全127条GWT；任务↔验收↔需求↔页面双向关联；未定义引用拒绝。 |
| F02 | P0 | scripts/check_package.py | 原checker对未定义验收、损坏JSON、任务环、无证据UAT、缺release图5种破坏都返回PASS。 | 重写检查器；源码中所有JSON严格解析，重复键/引用/依赖/状态/证据检查，并建立负向回归测试。 |
| F03 | P1 | specs/TRACEABILITY_MATRIX.md / canonical范围 | RQ18隐私与共同记录未完整纳入顶层R1范围追踪。 | 明确RQ01–15、RQ18–20 active；RQ16/RQ17 deferred，20RQ与12跨域要求全部处置。 |
| F04 | P1 | .codex/graphs/irl-r1-build.md | 原图是描述/箭头，缺上游schema/frontmatter、规范Nodes/Edges和完整终止/Review契约。 | 按reviewed-batch模板重写为draft blueprint；有界节点、START/END、执行路由/Review/预算；上游验证仍NOT_RUN。 |
| F05 | P1 | .codex/graphs/contracts/irl-r1-build/task-admission-pack.yaml | 目录指向build而graph_id指release，schema写为task-admission-pack-v1。发布图本身只是短草稿。 | 不伪造authority-critical完整合规；退役错误包，发布放roadmap/RELEASE_ADMISSION，取得真实权限后按上游/现有release controller创建。 |
| F06 | P1 | 00_START_HERE.md / root prompt | 包可放docs/project-irl，但执行指令默认所有路径从真实仓库根解析。 | 明确PACKAGE_ROOT与REPO_ROOT；Graph绑定增量合并实际注册表，不产生第二个STATUS。 |
| F07 | P1 | governance/STATUS.json / managed prompt | 实现授权PENDING，但缺清晰的实际用户授权入口和有限managed run预算闭环。 | BOOTSTRAP包含实际发送才生效的本地范围授权；3代理/120dispatch/240分钟均有限上限，不是工期；外部授权分离。 |
| F08 | P1 | codex prompts / loop说明 | 未提供完整Claude命令、取消/恢复与单写者监控规则。 | 分别提供Codex Goal、Claude Goal、可选只读Loop、真实job ID取消与resume；不杜撰Codex Loop。 |
| F09 | P1 | evidence requirements / real device语句 | when available措辞可能使真实设备成为可省略项。 | 真机、DevTools、Web后台E2E、runtime、独立review分别硬门；缺少任一项不能完整R1 UAT。 |
| F10 | P1 | design / UI_CONTRACT | 有页面名称但缺全页面状态、返回、深链及跳转守卫矩阵。 | 12页面/11R1＋后续PG11，navigation、tokens与逐页面异常/授权/弱网验收，保留Apple+Partiful方向。 |
| F11 | P1 | domain/API specs | 字段/接口/事务边界多为原则，执行Agent仍需自行补大量歧义。 | 57项API操作草案、45个schema；对象权限、EventVersion、容量/候补/短事务/outbox/未知效果/状态机详细契约。 |
| F12 | P1 | engineering/backlog.json | 按数字顺序阶段可能先发布后补审核，AI调用早于统一动作治理；任务另存状态。 | 调整依赖：outbox先于候补、治理先于AI、审核先于发布；3工单按依赖闭合分组18/14/3；状态只在STATUS。 |
| F13 | P1 | work_orders/WO-R1-01~03.md | 原阶段文件过短，缺可独立执行的任务合同。 | 3阶段scope/授权/回滚/交接 + 35逐任务契约与对应全部GWT断言。实际代码位置/测试命令仍须真实repo发现。 |
| F14 | P1 | STATUS / evidence | “原子更新”只是文字；缺CAS工具、候选清单与证据哈希/版本校验。 | 单主机合作式CAS+排他锁+原子replace；候选清单逐文件hash；receipt精确候选/冻结时间/真实artifact和case覆盖检查。 |
| F15 | P1 | CI / review evidence | 只有PASS字段不足以确保全部required jobs和真正独立review。 | CI作业集合与真实发现绑定逐项一致；作者/评审者不同、只读/候选不变；Goal评价器不算review。真实性仍需上游回读。 |
| F16 | P1 | environment/providers | 缺账号级能力盘点和真实提供方集成门；fixture容易被当完整能力。 | 能力矩阵、命令绑定、环境/secret隔离、feature flags及provider_integrations门；AI凭证缺失可继续手动开发但不宣称完整R1。 |
| F17 | P1 | ops / release | 三场真实试点与工程UAT/公众发布的先后不够清晰，可能形成循环依赖或提前上线。 | 工程UAT→账号/数据/值守/白名单试点授权→三场真实活动→正式公众发布批准；线上事故与恢复SOP。 |
| F18 | P2 | metrics / retention / roadmap | 指标成熟样本、数据保留审批、未来阶段交付边界不够细。 | 埋点词典/成熟cohort口径/费用非GMV/保留期提案/注销恢复标记；R1.1-R3明确闭锁与后续入场条件。 |
| F19 | P1 | package validation scope | 包检查通过被表述成整体工程控制已充分可用。 | 显式区分包结构、脚本测试、真实代码实现、CI/Review、提供方/真机、UAT、平台审核与部署；本次仅前两类实际验证。 |

## 四、新版覆盖与边界

保留同一父工单DRAFT-IRL-AUTO-003与T01–T35，避免新建重复工程身份。三阶段按真实依赖分配18/14/3任务。新增/完善127条Given/When/Then验收规格、20RQ＋12跨域要求、12页面及导航状态、57项API操作与45个schema、19个独立证据gate。所有API/数据/视觉token均是面向实施的提案，不是已部署代码。原Skill的STARGO专属例子通过Project adapter隔离，未引入CRM/DSH/Puter等不属于本项目的系统。

默认完整实现范围为PRD的R1；R1.1/R2/R3全项目路线和激活条件保留，但不能把尚未经运营/支付/类目/业务验证的阶段自动打开。首次执行仍需真实repo绑定；未知测试命令、AppID和目标环境不写猜测值。

## 五、实际验证

本包控制脚本采用Python 3.10+标准库，不安装依赖、不联网、不调用模型、不运行用户产品。执行记录见`validation/VERIFICATION_REPORT.json`和`validation/FINAL_TESTS.txt`。本次完成62项包工具自动化测试，包含正向控制、损坏JSON、双向引用、任务环、Graph节点、API引用、状态CAS/锁、候选漂移、伪造PASS、缺验收覆盖、CI漏项、假三场试点与不真实提供方证据。最初CI集合校验的两条测试真实失败后补上实现再重跑，RED记录保留。

初始check_gate --gate nick_uat **预期拒绝**：没有真实候选、CI、独立review、微信/真机/提供方证据。这个拒绝不是新版缺陷，而是避免错误放行的正向结果。

## 六、明确未执行与剩余风险

|项目|当前事实|
|---|---|
|用户真实Project IRL仓库绑定/代码修改|未执行；本次修订开发包|
|产品127条验收实际运行|未执行；127条是规格|
|真实CI、独立工程review、真机/Web/运行时E2E|未执行|
|Graph Engineering全局安装/运行|未执行|
|上游Graph validator|源码/模板可读，但容器下载失败，NOT_RUN；自有checker不是上游validator|
|完整OpenAPI标准验证|本地检查引用/结构；未调用外部OpenAPI校验器|
|微信主体/类目/备案/支付/AI数据合法性|账号级/专业核验尚未完成，不宣称合规通过|
|部署/迁移/真实外发/收费/自动订场|未授权且未执行|
|本次包语义审查|本助手自审＋实际自动化测试，不冒充另一位独立reviewer|

证据JSON和hash校验能够发现格式、版本与文件不一致，但不能证明一份伪造的“真机日志”真的来自真机，也不能认证人类批准。真实CI/账号/设备/权限必须由执行时的受信工具回读。CAS helper只面向单主机合作式单写者；它不提供跨主机分布式互斥，也不取代外部RBAC。

## 七、建议执行方式

采用一次明确的有限本地授权＋单个Root Supervisor＋原生Goal＋项目内Graph＋节点有限修复。Loop仅可选只读监控。先读取00_START_HERE与UPGRADE_FROM_V3，不能覆盖已经真实执行过的STATUS和证据。缺外部账号只阻断对应gate，继续其他可逆独立开发；不因此降低完成标准。

本次改进追求“缺什么能检查出来、卡在哪能恢复、何时完成有证据”，不做“文件越多就越完美”或“一条命令必定上线”的承诺。
