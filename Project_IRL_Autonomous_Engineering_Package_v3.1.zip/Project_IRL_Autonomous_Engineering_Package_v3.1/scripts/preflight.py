#!/usr/bin/env python3
"""Optional read-only local identity probe; no remote search, config writes or secret dump."""
import argparse,json,shutil,subprocess
from pathlib import Path

def probe(argv,cwd):
    try:
        p=subprocess.run(argv,cwd=cwd,text=True,capture_output=True,timeout=10,check=False)
        return {'argv':argv,'exit_code':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()}
    except (OSError,subprocess.TimeoutExpired) as ex:return {'argv':argv,'status':'UNAVAILABLE','error':str(ex)}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path,required=True);a=p.parse_args()
    if not a.repo.is_dir():p.error('repo must be an actual local directory')
    output={'package_root':str(Path(__file__).resolve().parents[1]),'requested_repo':str(a.repo.resolve()),'probes':[],'warning':'A version string does not prove /goal, /loop, Graph, actual permissions or live integration support. No state was modified.'}
    if shutil.which('git'):
        for args in [['rev-parse','--show-toplevel'],['rev-parse','--abbrev-ref','HEAD'],['rev-parse','HEAD'],['status','--porcelain']]:output['probes'].append(probe(['git',*args],a.repo))
    for name in ['codex','claude']:
        path=shutil.which(name)
        if path:output['probes'].append(probe([path,'--version'],a.repo))
    print(json.dumps(output,ensure_ascii=False,indent=2))
