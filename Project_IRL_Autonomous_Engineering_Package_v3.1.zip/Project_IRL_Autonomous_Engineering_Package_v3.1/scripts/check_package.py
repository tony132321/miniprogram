#!/usr/bin/env python3
"""Validate this delivery package, not product functionality. Python 3.10+."""
import argparse,json
from pathlib import Path
from package_lib import check_package
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    parser.add_argument('--verify-manifest',action='store_true')
    args=parser.parse_args();errors=check_package(args.root,args.verify_manifest)
    print(json.dumps({'package_contract':'FAIL' if errors else 'PASS','product_tests':'NOT_RUN_BY_THIS_COMMAND','upstream_graph_validator':'NOT_RUN_BY_THIS_COMMAND','errors':errors},ensure_ascii=False,indent=2))
    raise SystemExit(1 if errors else 0)
