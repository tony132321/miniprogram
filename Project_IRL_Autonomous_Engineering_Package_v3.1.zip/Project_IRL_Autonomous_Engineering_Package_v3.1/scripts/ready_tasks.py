#!/usr/bin/env python3
"""Read-only scheduling recommendation; never spawns an agent or grants permission."""
import argparse,json
from pathlib import Path
from package_lib import load,ready_batch,dag_errors
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--max',type=int,default=3);a=p.parse_args()
    try:
        tasks=load(a.root/'engineering/backlog.json')['items'];state=load(a.root/'governance/STATUS.json');errors=dag_errors({t['id']:t for t in tasks})
        if errors:raise ValueError('; '.join(errors))
        chosen=ready_batch(tasks,state['tasks'],min(a.max,3))
        print(json.dumps({'mode':'READ_ONLY_RECOMMENDATION_NOT_EXECUTION','local_authority':state['authority']['local_implementation']['state'],'dependency_ready':chosen,'note':'Actual path/DB/port locks, evidence and remaining approved budgets still need supervisor verification.'},ensure_ascii=False,indent=2))
    except (ValueError,KeyError,TypeError,OSError) as ex:
        print(json.dumps({'status':'BLOCKED','error':str(ex)},ensure_ascii=False));raise SystemExit(1)
