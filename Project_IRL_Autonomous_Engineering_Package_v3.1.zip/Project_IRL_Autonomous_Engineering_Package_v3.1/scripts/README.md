# 工具入口（Python 3.10+，标准库）

|脚本|作用|绝不代表|
|---|---|---|
|check_package.py|JSON严格解析、引用、覆盖、DAG、Graph蓝图结构、API内部引用、状态/证据和可选SHA清单|完整OpenAPI标准认证、上游Graph验证或产品通过|
|check_gate.py --gate nick_uat|检查候选manifest与receipt文件hash、必需case覆盖、CI集合、提供方/真机/人类批准字段|认证日志来源、自动批准UAT/部署|
|ready_tasks.py|只读推荐依赖就绪且声明资源不冲突的最多3任务|真正调度Agent、实际锁定数据库/端口或授予权限|
|preflight.py --repo ACTUAL_PATH|只读Git身份/dirty状态和存在的CLI版本探测|判断账号/命令surface一定可用|
|state_io.py|供Supervisor调用的单主机CAS更新函数|授权引擎或跨主机分布式锁|

检查器是开发辅助，不是安全沙箱。运行于受信本地工作区；不与恶意进程共用可写目录。它拒绝已存在符号链接和目录逃逸，但不声称抵御不受信操作系统级并发攻击。

更新状态示例（仅在真实授权后；不直接改变PASS/授权）：
```python
from pathlib import Path
import sys
package_root = Path('/actual/package/root')
sys.path.insert(0, str(package_root / 'scripts'))
from state_io import update_state
# expected_revision必须取自刚读取的当前STATUS；冲突后重新读取，不强行覆盖。
update_state(package_root, expected_revision=0,
             transform=lambda state: {**state, 'exact_resume_point': 'Verified next task action'},
             owner_session='actual-supervisor-session-id')
```

锁损坏/遗留默认不自动清理，避免双Supervisor。scope/授权/候选身份变化须按工单治理处理，不能滥用通用transform获得生产权限。
