"""Single-host cooperative CAS updates. Not a distributed lock or authorization engine.

Never steals stale locks. A verified owner must inspect a crashed writer before
manual recovery. Callers must authorize semantic changes; this helper does not.
"""
from __future__ import annotations
import json,os,socket,tempfile,uuid
from datetime import datetime,timezone
from pathlib import Path
from typing import Callable
from package_lib import load,safe_path
class StateConflict(RuntimeError):pass
class StateLocked(RuntimeError):pass

def update_state(root:Path,expected_revision:int,transform:Callable[[dict],dict],owner_session:str)->dict:
    if type(expected_revision) is not int or expected_revision<0 or not owner_session:raise ValueError('revision and owner session required')
    root=Path(root);path=safe_path(root,'governance/STATUS.json');lock=safe_path(root,'governance/STATUS.json.lock')
    token=str(uuid.uuid4());fd=None;tmp=None
    try:
        try:fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        except FileExistsError as ex:raise StateLocked('Existing lock; do not auto-steal: '+str(lock)) from ex
        with os.fdopen(fd,'w',encoding='utf8') as handle:
            fd=None;json.dump({'token':token,'session':owner_session,'pid':os.getpid(),'host':socket.gethostname()},handle);handle.flush();os.fsync(handle.fileno())
        current=load(path)
        if current.get('state_revision')!=expected_revision:raise StateConflict('Revision changed; reread and reconcile')
        schema=current.get('schema');updated=transform(current)
        if not isinstance(updated,dict) or updated.get('schema')!=schema:raise ValueError('Schema changes require explicit migration')
        updated['state_revision']=expected_revision+1;updated['updated_at']=datetime.now(timezone.utc).isoformat()
        raw=json.dumps(updated,ensure_ascii=False,indent=2,allow_nan=False)+'\n'
        tmpfd,tmp=tempfile.mkstemp(prefix='.STATUS-',suffix='.tmp',dir=path.parent)
        with os.fdopen(tmpfd,'w',encoding='utf8') as handle:handle.write(raw);handle.flush();os.fsync(handle.fileno())
        # Recheck the cooperative lock and path immediately before replacing.
        if load(lock).get('token')!=token:raise StateLocked('Lock ownership changed; refusing write')
        safe_path(root,'governance/STATUS.json');os.replace(tmp,path);tmp=None
        if os.name=='posix':
            dfd=os.open(path.parent,os.O_RDONLY)
            try:os.fsync(dfd)
            finally:os.close(dfd)
        return updated
    finally:
        if fd is not None:os.close(fd)
        if tmp is not None:
            try:os.unlink(tmp)
            except FileNotFoundError:pass
        try:
            # Never unlink another owner's lock.
            if lock.exists() and load(lock).get('token')==token:lock.unlink()
        except (OSError,ValueError,AttributeError):pass
