#!/usr/bin/env python3
"""Read-only gate evidence contract check. Does not authenticate actors or execute tests."""
import argparse,json
from pathlib import Path
from package_lib import gate_errors
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--gate',default='nick_uat',choices=['nick_uat','pilot_ready','public_r1_ready','live_verified']);a=p.parse_args()
    errors=gate_errors(a.root,a.gate)
    print(json.dumps({'gate':a.gate,'status':'BLOCKED' if errors else 'EVIDENCE_CONTRACT_SATISFIED','limits':'Structural consistency only; verify real CI/device/account provenance independently. No automatic authorization or state promotion.','errors':errors},ensure_ascii=False,indent=2))
    raise SystemExit(1 if errors else 0)
