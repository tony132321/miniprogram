"""Fail-closed structural checks for this package, NOT a product or identity verifier.

No network calls, subprocesses, model execution or deployment. Callers must verify
real provenance via their actual CI/account/runtime. JSON assertions alone are not proof.
"""
from __future__ import annotations
import hashlib,json,re
from datetime import datetime,timezone,timedelta
from pathlib import Path,PurePosixPath
from typing import Any
SOURCE_HASHES={
 '01_PRD_v1.0.md':'db75188f86e231db294b3925b7f80f9149792c65c62b31813303f4ee9b4c5f90',
 'governance/stargo-work-order_SKILL_v1.1.0.md':'f72f635b60593d41d69ce9c09aed8dc99519ac4e9306539cc505a99236a44111'}
TASK_STATES={'NOT_STARTED','IN_PROGRESS','LOCAL_VERIFIED','ACCEPTED','BLOCKED','STALE'}
GATE_STATES={'NOT_RUN','PASS','FAIL','BLOCKED','PARTIAL','UNKNOWN','STALE','MOCK'}

def digest(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def _pairs(pairs:list)->dict:
    out={}
    for k,v in pairs:
        if k in out:raise ValueError('duplicate JSON key: '+k)
        out[k]=v
    return out

def load(path:Path)->Any:
    return json.loads(path.read_text(encoding='utf-8'),object_pairs_hook=_pairs,
                      parse_constant=lambda x:(_ for _ in ()).throw(ValueError('non-finite JSON '+x)))

def safe_path(root:Path,relative:str)->Path:
    """Reject traversal, absolute paths and all symlink components. Local trusted workspace only."""
    if not isinstance(relative,str) or not relative or '\\' in relative or '\x00' in relative:
        raise ValueError('unsafe relative path')
    p=PurePosixPath(relative)
    if p.is_absolute() or '..' in p.parts or ':' in relative:
        raise ValueError('unsafe relative path: '+relative)
    current=root.resolve()
    for part in p.parts:
        current=current/part
        if current.is_symlink():raise ValueError('symlink path rejected: '+relative)
    if not current.resolve().is_relative_to(root.resolve()):raise ValueError('path escape')
    return current

def timestamp(value:Any)->datetime:
    if not isinstance(value,str):raise ValueError('missing timestamp')
    out=datetime.fromisoformat(value.replace('Z','+00:00'))
    if out.tzinfo is None:raise ValueError('timestamp requires timezone')
    return out

def _refs(value:Any):
    if isinstance(value,dict):
        if '$ref' in value:yield value['$ref']
        for v in value.values():yield from _refs(v)
    elif isinstance(value,list):
        for v in value:yield from _refs(v)

def _unique(items:list,label:str,errors:list)->dict:
    out={}
    for item in items:
        if not isinstance(item,dict) or not isinstance(item.get('id'),str):
            errors.append('invalid '+label+' identity');continue
        if item['id'] in out:errors.append('duplicate '+label+': '+item['id'])
        out[item['id']]=item
    return out

def dag_errors(tasks:dict)->list[str]:
    errors=[];visiting=set();visited=set()
    def visit(k):
        if k in visiting:errors.append('dependency cycle: '+k);return
        if k in visited:return
        visiting.add(k)
        for dep in tasks[k].get('depends_on',[]):
            if dep not in tasks:errors.append('undefined dependency: '+k+' -> '+dep)
            else:visit(dep)
        visiting.remove(k);visited.add(k)
    for k in tasks:visit(k)
    return errors

def _graph_errors(text:str)->list[str]:
    errors=[]
    if not text.startswith('---\n') or 'schema: graph-engineering/v1' not in text.split('---',2)[1]:errors.append('graph schema missing/invalid')
    for sec in ['Intent','Scope','Risk and Outcome Contract','State','Nodes','Execution Routing','Edges','Execution Policy','Review Policy','Execution','Governance']:
        if not re.search(r'^## '+re.escape(sec)+r'\s*$',text,re.M):errors.append('graph missing section '+sec)
    if 'profile: reviewed-batch/v1' not in text:errors.append('graph profile invalid')
    def rows(section):
        m=re.search(r'^## '+re.escape(section)+r'\s*\n(.*?)(?=^## |\Z)',text,re.M|re.S)
        if not m:return []
        lines=[x for x in m.group(1).splitlines() if x.strip().startswith('|')]
        return [[v.strip() for v in line.strip().strip('|').split('|')] for line in lines[2:]]
    nodes=rows('Nodes');edges=rows('Edges')
    if not nodes or not edges:errors.append('graph node/edge tables missing');return errors
    ids={x[0] for x in nodes}|{'START','END'}
    adjacency={k:[] for k in ids}
    for edge in edges:
        if len(edge)<5 or edge[0] not in ids or edge[1] not in ids:errors.append('graph invalid edge');continue
        adjacency[edge[0]].append(edge[1])
    def reach(start):
        seen=set();stack=[start]
        while stack:
            x=stack.pop()
            if x not in seen:seen.add(x);stack+=adjacency.get(x,[])
        return seen
    if ids-reach('START'):errors.append('graph unreachable nodes or END')
    for k in ids-{'END'}:
        if 'END' not in reach(k):errors.append('graph node has no terminal path: '+k)
    for budget in ['dispatch_count<=120','wall_minutes<=240','no_progress<=3','Maximum repair attempts: 1','access=read-only']:
        if budget not in text:errors.append('graph missing bound/review: '+budget)
    return errors

def receipt_errors(root:Path,r:dict,gate:str,state:dict,policy:dict)->list[str]:
    e=[]
    if not isinstance(r,dict):return ['receipt is not an object']
    for key in ['schema','id','gate','status','kind','candidate_id','candidate_digest','environment','actor','observed_at','checks','artifacts','limitations']:
        if key not in r:e.append('receipt missing '+key)
    if e:return e
    if r['schema']!='project-irl/evidence-v1' or r['status']!='PASS':e.append('receipt schema/status not passing')
    if r['gate']!=gate or r['kind'] not in policy.get('gate_types',{}).get(gate,[]):e.append('receipt wrong gate/kind')
    candidate=state.get('candidate',{})
    if r['candidate_id']!=candidate.get('id') or r['candidate_digest']!=candidate.get('content_digest'):e.append('receipt candidate mismatch')
    try:
        observed=timestamp(r['observed_at']);frozen=timestamp(candidate.get('frozen_at'))
        if observed<frozen:e.append('stale receipt predates frozen candidate')
        if observed>datetime.now(timezone.utc)+timedelta(minutes=5):e.append('future-dated receipt')
    except (ValueError,TypeError):e.append('receipt timestamp invalid/missing candidate freeze time')
    env=r['environment'];actor=r['actor']
    if not isinstance(env,dict) or env.get('kind') not in {'integration','candidate','controlled_pilot','production'} or not env.get('target'):e.append('receipt mock/unknown environment')
    if not isinstance(actor,dict) or any(not actor.get(x) for x in ['id','role','session_id']):e.append('receipt actor identity missing')
    if not isinstance(r['checks'],list) or not r['checks'] or any(not isinstance(x,dict) or not x.get('id') or x.get('status')!='PASS' for x in r['checks']):e.append('receipt checks missing/not all PASS')
    if not isinstance(r['limitations'],list):e.append('limitations must be explicit list')
    arts=r['artifacts']
    if not isinstance(arts,list) or not arts:e.append('receipt artifacts missing');arts=[]
    for a in arts:
        try:
            relative=a['path']
            if not relative.startswith('evidence/product/'):raise ValueError('not product evidence')
            path=safe_path(root,relative)
            if not path.is_file() or digest(path)!=a['sha256']:raise ValueError('artifact missing or hash mismatch')
        except (ValueError,KeyError,TypeError,OSError) as ex:e.append('receipt artifact: '+str(ex))
    if gate=='independent_review':
        if not isinstance(actor,dict) or actor.get('id') in candidate.get('author_ids',[]) or actor.get('role')!='independent_reviewer':e.append('self-review or invalid reviewer role')
        if isinstance(actor,dict) and actor.get('session_id') in candidate.get('author_session_ids',[]):e.append('reviewer session is an author session')
        if r.get('read_only') is not True or r.get('candidate_unchanged') is not True:e.append('review not immutable/read-only')
    if gate=='required_ci':
        jobs=r.get('required_jobs')
        if not isinstance(jobs,list) or not jobs or any(not isinstance(x,dict) or not x.get('name') or x.get('status')!='PASS' for x in jobs):e.append('required CI jobs missing or partial failure')
    if gate=='real_device_e2e':
        device=r.get('device')
        if not isinstance(device,dict) or any(not device.get(x) for x in ['platform','model','os_version','app_build','run_id']):e.append('real device identity missing')
    if gate=='provider_integrations':
        inventory=r.get('integrations',{})
        allowed={'wechat_login':{'LIVE_VERIFIED'},'ai_draft':{'LIVE_VERIFIED'},'moderation':{'LIVE_VERIFIED','MANUAL_QUEUE_VERIFIED'},'notifications':{'LIVE_VERIFIED','IN_APP_ONLY_DECLARED'}}
        if not isinstance(inventory,dict):e.append('integration inventory invalid')
        else:
            for name,modes in allowed.items():
                item=inventory.get(name,{})
                if not isinstance(item,dict) or item.get('mode') not in modes or item.get('mock') is not False or not item.get('evidence_ref'):
                    e.append('integration missing/unverified: '+name)
                else:
                    try:
                        ip=safe_path(root,item['evidence_ref'])
                        if not item['evidence_ref'].startswith('evidence/product/') or not ip.is_file():e.append('integration evidence missing: '+name)
                    except (ValueError,TypeError):e.append('integration evidence unsafe: '+name)
    if gate=='three_real_pilots':
        if r.get('real_activity') is not True or r.get('synthetic') is not False or not r.get('activity_id') or not r.get('independent_participant_evidence'):e.append('real pilot fields missing')
    if gate in {'nick_business_uat','pilot_authorization','production_release_approval'}:
        if not isinstance(actor,dict) or actor.get('role')!='human_owner' or not r.get('human_source_ref'):e.append('human approval source/owner required')
    return e

def gate_errors(root:Path,stage:str,state:dict|None=None)->list[str]:
    """Validate receipts and candidate artifacts; never promote state or authenticate provenance."""
    try:
        state=state if state is not None else load(root/'governance/STATUS.json')
        policy=load(root/'governance/GATE_POLICY.json')
        if stage not in policy['stage_gates']:return ['unknown gate stage: '+stage]
        e=[];candidate=state.get('candidate',{});repo=state.get('repo',{})
        for k in ['id','content_digest','manifest_ref','frozen_at','author_ids']:
            if not candidate.get(k):e.append('candidate missing '+k)
        if candidate.get('manifest_ref'):
            try:
                mp=safe_path(root,candidate['manifest_ref'])
                if not str(candidate['manifest_ref']).startswith('evidence/product/'):raise ValueError('manifest not product evidence')
                if digest(mp)!=candidate.get('content_digest'):raise ValueError('candidate manifest digest mismatch')
                manifest=load(mp)
                if manifest.get('candidate_id')!=candidate.get('id'):raise ValueError('candidate manifest ID mismatch')
                repo_root=Path(repo.get('root') or '')
                if not repo.get('root') or not repo_root.is_dir():raise ValueError('actual repo root not bound')
                if not manifest.get('files'):raise ValueError('empty candidate manifest')
                for f in manifest['files']:
                    fp=safe_path(repo_root,f['path'])
                    if not fp.is_file() or digest(fp)!=f['sha256']:raise ValueError('candidate file changed: '+f['path'])
            except (ValueError,TypeError,KeyError,OSError) as ex:e.append('candidate verification: '+str(ex))
        for gate in policy['stage_gates'][stage]:
            st=state.get('gates',{}).get(gate,{})
            if st.get('status')!='PASS':e.append(gate+': '+str(st.get('status','MISSING')))
            refs=st.get('evidence_refs',[])
            if not refs:e.append(gate+': no receipt');continue
            covered=set();pilots=set();ci_jobs=set()
            for reference in refs:
                try:
                    if not reference.startswith('evidence/product/'):raise ValueError('receipt not in product evidence directory')
                    receipt=load(safe_path(root,reference));errors=receipt_errors(root,receipt,gate,state,policy)
                    e += [gate+': '+x for x in errors]
                    if not errors:
                        covered.update(x['id'] for x in receipt['checks'])
                        if gate=='three_real_pilots':pilots.add(receipt['activity_id'])
                        if gate=='required_ci':ci_jobs.update(x['name'] for x in receipt['required_jobs'])
                except (ValueError,KeyError,TypeError,OSError) as ex:e.append(gate+': invalid receipt: '+str(ex))
            if gate=='required_ci':
                try:
                    binding=load(root/'environment/COMMAND_BINDINGS.json')
                    names=binding.get('required_check_names');source=binding.get('required_checks_source_ref')
                    if not isinstance(names,list) or not names or not source or not safe_path(root,source).is_file():
                        raise ValueError('required check binding is unknown or has no source')
                    if set(names)!=ci_jobs:e.append('required CI coverage differs from bound required checks')
                except (ValueError,TypeError,KeyError,OSError) as ex:e.append('required check binding: '+str(ex))
            missing=set(policy.get('required_case_ids',{}).get(gate,[]))-covered
            if missing:e.append(gate+': missing case coverage '+', '.join(sorted(missing)))
            if gate=='three_real_pilots' and len(pilots)<3:e.append('three_real_pilots: fewer than 3 distinct actual activities')
        return e
    except (ValueError,KeyError,TypeError,OSError) as ex:return ['gate malformed input: '+str(ex)]

def ready_batch(tasks:list[dict],states:dict,maximum:int=3)->list[str]:
    if not isinstance(maximum,int) or isinstance(maximum,bool) or maximum<1:raise ValueError('positive finite maximum required')
    selected=[];domains=set();locks=set();paths=[]
    done={'LOCAL_VERIFIED','ACCEPTED'}
    def overlap(a,b):return a==b or a.startswith(b.rstrip('/')+'/') or b.startswith(a.rstrip('/')+'/')
    for t in tasks:
        if states.get(t['id'],{}).get('status','NOT_STARTED') not in {'NOT_STARTED','STALE'}:continue
        if any(states.get(d,{}).get('status') not in done for d in t.get('depends_on',[])):continue
        domain=t.get('write_domain');newpaths=t.get('write_paths',[]);newlocks=set(t.get('resource_locks',[]))
        if (domain and domain in domains) or newlocks&locks or any(overlap(a,b) for a in newpaths for b in paths):continue
        selected.append(t['id']);domains.add(domain);locks|=newlocks;paths+=newpaths
        if len(selected)>=maximum:break
    return selected

def check_package(root:Path,verify_manifest:bool=False)->list[str]:
    root=root.resolve();e=[];data={}
    required=['01_PRD_v1.0.md','governance/stargo-work-order_SKILL_v1.1.0.md','governance/CANONICAL_WORK_ORDER.md','governance/STATUS.json','governance/GATE_POLICY.json','governance/RUN_POLICY.json','specs/requirements.json','specs/acceptance_cases.json','engineering/backlog.json','design/pages.json','design/navigation.json','specs/openapi.json','work_orders/index.json','environment/FEATURE_FLAGS.json','prompts/ROOT_SUPERVISOR.md','prompts/BOOTSTRAP_AND_AUTHORIZE.txt','codex/GOAL_COMMAND.txt','claude/GOAL_COMMAND.txt','claude/LOOP_MONITOR_COMMAND.txt','.codex/graphs/INDEX.md','.codex/graphs/irl-r1-build.md','roadmap/FUTURE_STAGES.md','roadmap/RELEASE_ADMISSION.md']
    for p in required:
        try:
            if not safe_path(root,p).is_file():e.append('missing file: '+p)
        except ValueError as ex:e.append(str(ex))
    for p in sorted(root.rglob('*.json')):
        if any(x in p.parts for x in ['__pycache__','.git']):continue
        try:
            rel=p.relative_to(root).as_posix();data[rel]=load(safe_path(root,rel))
        except (ValueError,OSError) as ex:e.append('JSON '+str(p.relative_to(root))+': '+str(ex))
    for p,h in SOURCE_HASHES.items():
        try:
            if digest(safe_path(root,p))!=h:e.append('source hash changed: '+p)
        except (ValueError,OSError):e.append('source hash unreadable: '+p)
    if any(x.startswith(('missing file','JSON')) for x in e):return e
    try:
        tasks=_unique(data['engineering/backlog.json']['items'],'task',e)
        cases=_unique(data['specs/acceptance_cases.json']['cases'],'acceptance',e)
        reqs=_unique(data['specs/requirements.json']['items'],'requirement',e)
        pages=_unique(data['design/pages.json']['pages'],'page',e)
        if data['engineering/backlog.json']['task_count']!=len(tasks):e.append('task count mismatch')
        if data['specs/acceptance_cases.json']['case_count']!=len(cases):e.append('case count mismatch')
        if set(tasks)!={f'T{i:02}' for i in range(1,36)}:e.append('original task identity changed')
        if not {f'RQ{i:02}' for i in range(1,21)}<=set(reqs):e.append('required RQ01-RQ20 missing (includes RQ18)')
        if set(pages)!={f'PG{i:02}' for i in range(1,13)}:e.append('page coverage incomplete')
        e+=dag_errors(tasks)
        for k,t in tasks.items():
            if 'status' in t:e.append('duplicate mutable task status '+k)
            if not t.get('acceptance'):e.append('task without acceptance '+k)
            for c in t.get('acceptance',[]):
                if c not in cases:e.append('undefined acceptance '+k+' -> '+c)
                elif k not in cases[c]['task_ids']:e.append('task/case backlink mismatch '+k+' '+c)
            for rq in t.get('requirement_ids',[]):
                if rq not in reqs:e.append('undefined requirement '+rq)
            if not safe_path(root,t['spec_file']).is_file():e.append('missing task spec '+k)
        for k,c in cases.items():
            if not c.get('given') or not c.get('when') or not c.get('then'):e.append('empty acceptance '+k)
            for field,target in [('task_ids',tasks),('requirement_ids',reqs),('page_ids',pages)]:
                for ref in c.get(field,[]):
                    if ref not in target:e.append('acceptance undefined '+field+' '+ref)
            if not c.get('task_ids') or not c.get('requirement_ids'):e.append('unowned acceptance '+k)
        for k,r in reqs.items():
            if not r.get('task_ids') or not r.get('acceptance_ids'):e.append('uncovered requirement '+k)
            for c in r.get('acceptance_ids',[]):
                if c not in cases:e.append('requirement undefined acceptance '+k+' '+c)
            if k not in {'RQ16','RQ17'} and r.get('stage')!='R1':e.append('active requirement stage drift '+k)
        for p in pages.values():
            if p['id']=='PG11' and p.get('enabled_in_r1') is not False:e.append('future page enabled')
            if not p.get('mandatory_states'):e.append('page states missing')
        nav=data['design/navigation.json']
        if nav.get('r1_tabs')!=['PG02','PG03','PG10']:e.append('navigation tabs drift')
        for edge in nav['edges']:
            if edge.get('from') not in pages or edge.get('to') not in pages:e.append('navigation undefined page')
        for name,f in data['environment/FEATURE_FLAGS.json']['flags'].items():
            if f['stage']!='R1' and f.get('default') is not False:e.append('future flag enabled '+name)
        orders=data['work_orders/index.json']['orders'];flat=[t for x in orders for t in x['task_ids']]
        if len(flat)!=len(set(flat)) or set(flat)!=set(tasks):e.append('work-order partition invalid')
        phase={t:i for i,x in enumerate(orders) for t in x['task_ids']}
        for k,t in tasks.items():
            if any(phase.get(dep,999)>phase.get(k,-1) for dep in t['depends_on']):e.append('work-order forward dependency '+k)
        for goalfile in ['codex/GOAL_COMMAND.txt','claude/GOAL_COMMAND.txt']:
            text=(root/goalfile).read_text().strip()
            if not text.startswith('/goal ') or not 0<len(text[6:])<=4000:e.append('goal length/syntax invalid '+goalfile)
        e+=_graph_errors((root/'.codex/graphs/irl-r1-build.md').read_text())
        api=data['specs/openapi.json'];opids=[]
        for reference in _refs(api):
            if not isinstance(reference,str) or not reference.startswith('#/'):e.append('API reference external/invalid');continue
            value=api
            try:
                for part in reference[2:].split('/'):value=value[part.replace('~1','/').replace('~0','~')]
            except (KeyError,TypeError):e.append('API reference dangling: '+reference)
        for path,methods in api['paths'].items():
            for method,op in methods.items():
                opids.append(op['operationId'])
                if method!='get' and not op.get('requestBody'):e.append('API mutation missing body '+path)
        if len(opids)!=len(set(opids)):e.append('API operation ID duplicate')
        s=data['governance/STATUS.json'];policy=data['governance/GATE_POLICY.json']
        if s.get('schema')!='project-irl/status-v2' or type(s.get('state_revision')) is not int or s['state_revision']<0:e.append('state schema/revision invalid')
        if set(s.get('tasks',{}))!=set(tasks):e.append('state task set mismatch')
        if set(s.get('gates',{}))!=set(policy['gate_types']):e.append('state gate set mismatch')
        if s.get('active_graph')!='irl-r1-build':e.append('active graph mismatch')
        for k,t in s.get('tasks',{}).items():
            if t.get('status') not in TASK_STATES:e.append('invalid task state '+k)
            if t.get('status') in {'LOCAL_VERIFIED','ACCEPTED'} and not t.get('evidence_refs'):e.append('task verified without evidence '+k)
        for k,g in s.get('gates',{}).items():
            if g.get('status') not in GATE_STATES:e.append('invalid gate state '+k)
            if g.get('status')=='PASS':
                if not g.get('evidence_refs'):e.append('PASS without evidence '+k)
                for reference in g.get('evidence_refs',[]):
                    try:
                        if not reference.startswith('evidence/product/'):raise ValueError('not product evidence')
                        e+=['invalid PASS receipt '+k+': '+x for x in receipt_errors(root,load(safe_path(root,reference)),k,s,policy)]
                    except (ValueError,KeyError,TypeError,OSError) as ex:e.append('invalid PASS receipt '+k+': '+str(ex))
        claim={'READY_FOR_NICK_UAT':'nick_uat','PILOT_READY':'pilot_ready','PUBLIC_R1_READY':'public_r1_ready','LIVE_VERIFIED':'live_verified'}.get(s.get('run_state'))
        if claim:
            e+=['unsubstantiated status: '+x for x in gate_errors(root,claim,s)]
        for gate,refs in policy['required_case_ids'].items():
            if gate not in policy['gate_types'] or not set(refs)<=set(cases):e.append('gate policy undefined cases '+gate)
        run=data['governance/RUN_POLICY.json']
        for key in ['max_parallel_subagents','max_dispatched_work_items','max_wall_clock_minutes','max_same_root_cause_repairs','max_no_progress_checks']:
            if type(run.get(key)) is not int or run[key]<=0:e.append('run bound missing '+key)
        if run.get('automatic_budget_renewal') is not False:e.append('run automatic renewal forbidden')
    except (KeyError,TypeError,AttributeError,IndexError,ValueError,OSError) as ex:e.append('malformed contract: '+str(ex))
    if verify_manifest:
        try:
            manifest=load(root/'PACKAGE_MANIFEST.json')
            for file,h in manifest['immutable_files'].items():
                if digest(safe_path(root,file))!=h:e.append('manifest hash mismatch '+file)
        except (KeyError,ValueError,TypeError,OSError) as ex:e.append('manifest invalid: '+str(ex))
    return e
