# 开始：让代码 Agent 接手，而不是让你逐项指挥

## 1. 放置与路径

解压后保留完整目录。已有仓库可把目录放在 `docs/project-irl/`，但**这个目录是 PACKAGE_ROOT，不是 REPO_ROOT**。
首次提示要求 Agent 分别绑定这两个绝对路径；本包文内无前缀的相对路径均相对于 PACKAGE_ROOT。
真实代码、AGENTS/CLAUDE、CI、分支保护属于 REPO_ROOT，不能误读包内README当真实工程说明。

旧包已经用起来时先读 `UPGRADE_FROM_V3.md`：不得用初始 STATUS 覆盖已经验证的运行状态。
本包不自动安装任何全局 Skill、覆盖 AGENTS.md 或改 GitHub、微信和生产账户。

## 2. 首次接手提示词（先做只读核验与受控范围启动）

复制 `prompts/BOOTSTRAP_AND_AUTHORIZE.txt` 到打开了真实项目的 Codex 或 Claude Code。
它含可选的一次性本地工程授权条款：只有你实际发送且目标仓库已经明确，执行 Agent 才能记录为授权。
该条款不授权 push、PR、merge、远程部署、生产迁移、真实外发、付费供应商调用或未来阶段。

默认建议的 managed session 预算是最多3个并行子代理、120个dispatch、240分钟 wall-clock、连续3次无进展停止。
这些是**运行上限建议，不是工期/完成时间承诺**；当前包内授权仍PENDING，Agent不可自行批准或放大。
预算到限先保存准确断点，不把截止当任务完成；续跑也不清零同根因修复次数。

## 3. 选择一个主执行器

**Codex**：先由 Agent核验版本、实际 `/goal` 可见性、工具权限和 Skill 安装状态，再复制 `codex/GOAL_COMMAND.txt`。
**Claude Code**：优先用已核验可用的 `/goal`，复制 `claude/GOAL_COMMAND.txt`。
无 Goal 的宿主使用 `prompts/ROOT_SUPERVISOR.md`；没有独立 reviewer 能力就完成可独立开发内容，并把review门禁标BLOCKED。
不要在两个会话同时启动写同一个工作区的根Supervisor。

Claude 的 `/loop` 是可选监控：先取得监控授权，再执行 `claude/LOOP_MONITOR_COMMAND.txt`。
它只读状态/已有检查结果并提示阻塞，不派发writer、不重跑整个工程、不直接修改STATUS。
记录工具返回的真实job ID；到完成/预算到限/owner暂停时按 `claude/CANCEL_AND_RESUME.md` 取消该job。

## 4. Graph Engineering 的位置

包里的 `.codex/graphs/` 是**未安装、未运行的契约蓝图**。路径均相对于PACKAGE_ROOT。
在目标仓库使用上游Skill前，先按 `prompts/GRAPH_BINDING.md` 将蓝图绑定到实际治理根、合并唯一registry并调整路径；不复制出第二套运行状态。
已存在正式Graph优先增量演进；有冲突则出局部补丁，不覆盖。
上游Skill的安装需先验证真实可用安装器、现有版本与供应链来源。本包没有替你安装它。

## 5. 包检查（Python 3.10+，任何目录都能运行）

```bash
python3 /实际路径/Project_IRL_Autonomous_Engineering_Package_v3.1/scripts/check_package.py
python3 -m unittest discover -s /实际路径/Project_IRL_Autonomous_Engineering_Package_v3.1/tests -v
python3 /实际路径/Project_IRL_Autonomous_Engineering_Package_v3.1/scripts/check_gate.py --gate nick_uat
```

初始包前两项应通过；最后一项**应拒绝**，因为没有软件代码、真实CI、真机或评审证据。
`check_gate.py` 只检查证据契约，不认证提供方真实性，也不授予外部权限。

## 6. 软件真正做到哪里

目标仓库确定前，代码路径、框架版本、测试命令、微信AppID、部署目标都保持UNKNOWN。
Agent在T01/T02发现实际命令并写入命令绑定；禁止杜撰`npm test`或不存在的测试项目。
完整R1工程闭环优先；R1.1/R2/R3只有计划与闸门，不算已开发，也不默认启用。
