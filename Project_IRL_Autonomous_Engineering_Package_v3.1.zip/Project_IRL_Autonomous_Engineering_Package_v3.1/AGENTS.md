# Package-local instructions only

This directory is an engineering specification package, not proof of the product repository root.
Do not overwrite a target repository's AGENTS.md with this file.
Use 00_START_HERE.md and governance/PROJECT_ADAPTER.md. Product source files may live elsewhere.

<!-- graph-engineering:start -->
Read `.codex/graphs/INDEX.md` before interpreting package Graph blueprints.
The canonical run-state artifact is `governance/STATUS.json`, relative to PACKAGE_ROOT.
The Graph is draft, not installed or executing. Bind the actual governance root and adjust all artifact paths during target integration. Preserve one status source and any stricter existing repository instructions.
Native Supervisor orchestration executes only the authorized scope. No package validator, graph file, or receipt grants authority. Follow the declared model-catalog discovery, bounded loops, immutable-candidate independent review, and stop conditions.
<!-- graph-engineering:end -->
