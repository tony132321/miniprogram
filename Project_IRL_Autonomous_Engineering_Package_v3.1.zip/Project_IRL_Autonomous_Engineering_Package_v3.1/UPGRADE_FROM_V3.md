# v3.0 → v3.1 增量升级

父工单保留 `DRAFT-IRL-AUTO-003`。本次是该工单的开发包修订，不是新业务需求。

1. 只读确认旧PACKAGE_ROOT、实际REPO_ROOT、当前分支/候选/工单/未提交修改，保存旧包哈希。
2. 如果旧包从未绑定仓库且STATUS仍初始状态，可完整替换开发包目录；不顺带替换产品代码。
3. 如果已经运行，保留旧STATUS和证据原件，按新schema逐字段迁移到新STATUS；记录 `migration_from`、旧文件sha256、映射、未能迁移的UNKNOWN。不得重置当前task、授权、候选或修复累计次数。
4. 任务仍是T01–T35；原不存在的验收ID现在都有定义。旧的8条验收ID保留。新加入的验收规格使旧的笼统“PASS”不再足以证明整个任务完成；按影响重验，不全项目重做。
5. 移除backlog/各工单中的可变状态副本，以STATUS为唯一运行事实。各task的status_ref只指向STATUS。
6. `T17` outbox/任务基础前置；`T30` AI工具鉴权与 `T28` 审核前置。三工单改为依赖闭合的18/14/3任务分组，不按编号机械执行。
7. 原发布Graph只是草图，且admission文件错目录、schema、graph_id。保留其历史事实到审查报告，迁移为 `roadmap/RELEASE_ADMISSION.md`，不把它当已经可执行的authority-critical Graph。
8. 包内Graph是蓝图；按GRAPH_BINDING绑定实际根目录、合并registry与AGENTS块，再用**实际安装的上游validator**检查。此步骤不是本包离线检查的替代名称。
9. 通过新包检查和负向测试后，运行当前软件测试/E2E；二者不可互相替代。
10. 做一次新候选独立评审，保留准确断点。没有实际用户重授权，不继承已过期/不同环境/不同payload的许可。

旧测试证据不得删除；用supersedes指向被替代记录。源PRD和Skill字节未变，任何将来修改须显式记录修订。
