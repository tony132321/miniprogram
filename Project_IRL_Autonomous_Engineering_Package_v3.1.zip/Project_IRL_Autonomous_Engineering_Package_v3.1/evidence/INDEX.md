# 证据目录

本目录初始没有任何软件PASS证据。`audit/`和`validation/`只属于开发包自检，不可用作产品门禁。

目标运行后建议按候选放置：
`evidence/product/<candidate>/tests/`、`ci/`、`review/`、`wechat/`、`devices/`、`web-ops/`、`readback/`、`recovery/`、`uat/`、`pilots/`。
STATUS gate只引用相应receipt JSON。历史receipt不可覆盖，新证据用supersedes引用。

所有路径相对于PACKAGE_ROOT；拒绝绝对路径、..、symlink越界和未脱敏敏感内容。
三场试点不得用三个虚拟event替代；保存实际举办时间、独立账号同意/证据和投诉处置，不公开个人身份资料。
