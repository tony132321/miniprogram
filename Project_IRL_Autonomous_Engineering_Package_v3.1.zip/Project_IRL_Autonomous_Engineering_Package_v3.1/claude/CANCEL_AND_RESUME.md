# Claude Goal / Loop 的实际用法

先发送BOOTSTRAP_AND_AUTHORIZE，再使用GOAL_COMMAND。只有实际运行界面支持命令才使用；版本号不证明特定surface功能可用。没有原生命令时按ROOT_SUPERVISOR在当前会话执行并写checkpoint，不伪造定时能力。

`/loop 10m ...` 是可选的定时只读巡检，不是开发主控制器。避免与主Goal抢同一状态写锁。创建后记录真实返回的job ID与创建时间；由Supervisor写入STATUS.run.monitor_job_id，监控自身不写工程状态。

取消时对Claude说：`Cancel the Project IRL read-only monitor with the exact job ID recorded in governance/STATUS.json. Confirm the cancellation using the current scheduler's list/readback.` 让它使用当前实际提供的任务列表/取消工具，不编造`/loop stop`。

当前公开文档描述了固定周期任务的到期与恢复规则；本包不依赖任务永远在线。换机器、关闭runtime、恢复session或压缩上下文后，先检查现有任务与日志，禁止重复创建。Goal的原生内部计数不能代替包中累积预算。只有一个Supervisor会话保有写权限；新会话接手先核对锁/候选/旧任务，绝不自动抢锁。

Goal评价器看会话，不独立验证代码/运行时；Loop触发次数不是交付进度。完成或阻塞停机时取消巡检并回读，留下精确恢复点。
