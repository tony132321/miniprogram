# 状态、候选与证据协议

## 唯一状态和并发

STATUS包含task progress、gate状态、运行预算、授权引用、候选与精确断点。backlog/工单/Graph不另存可变进度。
只有当前根Supervisor更新STATUS。worker只返回结构化结果；只读监控不写状态。
`scripts/state_io.py`使用同目录排他锁、expected revision、临时文件、fsync及原子replace。
锁文件遇到崩溃遗留时默认拒绝接管；先核对原进程/会话/外部动作，再由授权操作者清理，不自动按墙钟偷锁。
多主机共享存储的分布式互斥不由本工具保证；那种运行方式必须使用现有正式协调设施，否则串行。

## 任务与阶段

NOT_STARTED → IN_PROGRESS → LOCAL_VERIFIED / BLOCKED → ACCEPTED。
LOCAL_VERIFIED可以让依赖任务继续集成，不表示真人/提供方/真机已验收。
ACCEPTED要求对应被采用范围的实际证据与独立评审；最终阶段始终以GATE_POLICY为准。
按需求影响把新候选的旧tests/review/E2E标为STALE或NOT_RUN，不能重用旧PASS。

## 候选冻结

候选至少包含git SHA（存在时）、完整代码/config/schema/build inputs清单及content digest、author IDs。
脏工作区不能只用HEAD代表改动：还要记录diff和未跟踪的目标文件；任何会影响运行的改变都要重新计算digest。
独立reviewer必须读取同一候选，角色和session可核验。自称“独立评审通过”不是独立性证据。

## 证据最小字段

遵循schemas/evidence.schema.json。每条记录含gate、status、kind、candidate_id/content_digest、environment、actor/session、observed_at、checks、真实artifact引用及sha256、limitations。
独立评审者不能出现在candidate.author_ids中；真人UAT/发布批准必须有可追溯的用户决定来源。
provider/tool原始日志应脱敏，但不能仅留下模型生成的总结。

## 工具能保证什么

check_gate检查结构、候选绑定、文件哈希、必需场景覆盖、独立身份声明、真机/试点字段和禁止mock标记。
它不能独立证明一个声称来自真机的日志真实，也不能让JSON文件替代平台RBAC、工具权限、人类授权或真实readback。
因此输出 `EVIDENCE_CONTRACT_SATISFIED` 不等于外部系统已放行。Reviewer/CI/提供方回读仍需实际执行。

## 暂停与续跑

预算、尝试次数和原started_at存在STATUS；Codex/Claude会话恢复即使重置自身计时，也不重置项目预算。
无进展=没有新通过的实际验收、缩小的错误集合、明确的阻塞定位或有效代码变化；仅重复读文档不算进展。
保存：当前task和node、正在运行的命令/任务ID、资源租约、当前候选、最后真实证据、阻塞和一个可执行下一步。

## 机器可查的候选清单格式
`candidate.manifest_ref`指向`evidence/product/candidate-manifest.json`。该文件含`candidate_id`和`files`数组，每项为真实REPO_ROOT相对`path`与`sha256`；清单应覆盖实际完整产品候选而非任意挑一个文件。`candidate.content_digest`为该清单文件原始字节SHA-256，`candidate.frozen_at`为带时区冻结时间，`author_ids`为全部作者，`author_session_ids`为作者会话。校验器逐项比对文件，并拒绝早于冻结时间或候选hash不符的收据。清单完整性仍需真实review/构建系统核验。

CI收据须列出`required_jobs`，并与environment/COMMAND_BINDINGS.json中已发现的`required_check_names`集合一致；该绑定的来源须可回读，不能让执行Agent自己删去失败job。未知required checks即BLOCKED。

## 提供方不是fixture
完整R1的provider_integrations门禁要求微信登录、AI草稿的真实已授权集成证据；审核可为已验证外部服务或真实人工审核队列；通知允许PRD规定的仅小程序内消息降级，但必须明确声明不能外部送达。integrations字段分别记录wechat_login、ai_draft、moderation、notifications的mode/mock/evidence_ref。缺AI凭证仍可继续全部独立手动链路开发，但不能把未实现AI的缩减版本叫完整R1通过；缩减UAT范围须owner明确更新同一工单和对应验收，不让Agent自己豁免。
