---
name: stargo-work-order
description: Use when Nick asks to create, submit, revise, continue, or validate a STARGO WORK development work order; says “提交开发工单”; or provides a requirement, screenshot, bug, integration request, or feature request that should become a controlled engineering ticket.
---

# STARGO WORK · 提交开发工单

**Skill version:** 1.1.0  
**Updated:** 2026-09-15  
**Owner:** Nick Wei / STARGO  
**Primary trigger:** `提交开发工单`

> 本 Skill 负责把 Nick 的业务需求转成 **有边界、可执行、可验证、可恢复、可交接** 的 STARGO WORK 开发工单。  
> 它不是第二套开发控制器，不替代现有 `stargo-delivery`、项目宪法、GitHub 工单权威、CI、Release Guardian、部署门禁或 Nick 的最终业务 UAT。

---

## 1. Core Principle

**先确认真实现状，再决定改什么；先复用，再开发；先定义验收，再写代码；没有证据，就不能宣布完成。**

对任何 STARGO WORK 工单，必须同时保护以下原则：

1. **Resume, don't re-audit.** 从当前已接受的 checkpoint / handoff / active work order 继续，不重新做全项目盘点。
2. **One canonical work order.** 同一需求只保留一个权威工单；更新已有工单优先于新建重复工单。
3. **Reuse before build.** 先查现有代码、模块、历史 PR、Route C、STARGO OS、已安装开源组件和现有 Skill；禁止重复造轮子。
4. **Evidence over claims.** 不把模型自述、截图、HTTP 200、Mock、目录存在、PR 创建、CI 局部绿或代码写完当成业务完成。
5. **Acceptance before implementation.** 正常、异常、权限、回归、恢复、真实 E2E 的验收条件必须在实现前明确。
6. **Separate authority.** 工单创建、代码实现、Git 写入、push、PR、merge、部署、迁移、改密、真实客户外发分别授权。
7. **Nick does business UAT.** Nick 负责业务范围、关键审批与真实浏览器业务验收；不要求 Nick 充当代码、安全或基础设施技术评审员。
8. **Unknown means UNKNOWN.** 路径、版本、Issue 编号、测试命令、部署状态、预算、授权、账号、VPS 状态无法核实时写 `UNKNOWN` / `BLOCKED` / `NOT_RUN`，禁止编造。
9. **No silent scope expansion.** 当前需求之外的未来桌面端、移动端、小程序、重构、平台替换、数据库替换、第二套 CRM/Loop/Controller 默认不进入本工单。
10. **Real E2E is a hard gate.** 用户可见功能没有真实 Browser/Desktop E2E、实际 Runtime、权威回读、必需测试与独立评审，就不能进入 Nick UAT。

---

## 2. Trigger Rules

### 2.1 Direct triggers

加载本 Skill 的典型情况：

- `提交开发工单`
- `提交开发工单：……`
- `帮我提交工单`
- `按我们的开发工单流程来`
- `这个要不要开工单`
- `把这个需求整理成开发工单`
- `继续这个工单`
- `检查这个工单有没有做完`
- Nick 提供截图 / Bug / 新功能 / 集成需求，并明确要进入 STARGO WORK 开发流程

如果触发词前面已经有明确需求，**直接复用前文需求，不重复问 Nick 已经回答过的问题。**

### 2.2 Non-triggers

以下不构成提交请求：

- 只是引用或讨论“提交开发工单”这个词
- `不要提交开发工单`
- 只问某个技术概念，没有要求进入工程流程
- 只要求解释已有工单，不要求修改或提交

### 2.3 No requirement at all

只有在完全没有需求上下文时，最多问一句：

> 这次想改什么？一句话或截图都可以。

---

## 3. Unknowns Pass

在写工单前快速完成一次 unknowns pass。

### Known knowns
Nick 已明确说过的目标、界面、业务行为、范围、禁改项、参考截图、指定模块、已有决策。

### Known unknowns
会实质影响方案的未知项，例如：

- 当前真实仓库 / worktree / branch / HEAD
- 是否已有相同工单、PR 或功能
- 当前 canonical work-order source
- 实际测试命令
- 当前部署版本
- 真实权限 / 账号 / API 可用性
- 是否涉及迁移、外发、付费调用或生产写入

### Unknown knowns
Nick 往往在看到结果后才能判断的内容，例如：

- UI 是否符合参考设计语言
- 操作流程是否顺手
- 哪个交互应保留
- 哪个结果才算“像原来系统”

优先通过已有 UI、截图、现有行为和 Nick 已批准的设计来推断，不让 Nick 做陌生技术选择。

### Unknown unknowns
主动检查：

- 重复工单
- 重复造轮子
- 隐藏的共享注册表 / schema / auth / routing 冲突
- PR 已被新 PR supersede
- 当前部署与 Git HEAD 漂移
- mock / demo 被误当真实能力
- CI 实际没有运行
- 外部副作用结果不明导致重复发送
- 安全边界只在前端存在
- 旧审批或旧会话继续复用失效权限

**最多问 3 个高影响问题。能用安全假设继续就不要中断 Nick。**

---

## 4. First Action: Reality Check

任何工单都先做**最小相关核查**，不是全项目审计。

按需求相关性检查：

1. 当前项目 instructions / constitution / AGENTS.md / CLAUDE.md。
2. 当前 accepted checkpoint / handoff / work-order ledger。
3. 同类 GitHub Issue、PR、branch、worktree。
4. 相关代码路径、路由、schema、API、测试。
5. Route C / STARGO OS / STARGO WORK 旧实现中是否已有可复用模块。
6. 已安装的 connector / plugin / open-source component / Skill。
7. 当前目标环境、真实版本和已知部署状态。
8. 共享资源：数据库、CRM、registry、auth、DSH、Chatwoot、Puter、runtime、VPS、外部通道。

### Reality-check rules

- 不因为记忆中“应该有”就声称存在。
- 不因为 GitHub 搜索失败就声称仓库不存在。
- 不因为历史报告说 PASS 就当当前版本仍 PASS。
- 不因为 PR 已合并就当已部署。
- 不因为 VPS 有文件就当正确服务正在运行。
- 不因为 API 200 就当业务闭环成功。
- 不因为 UI 显示成功就当后端权威状态已写入。

---

## 5. Duplicate / Reuse Gate

在新建任务前回答：

1. 是否已有相同 outcome 的工单？
2. 是否已有 branch / PR 正在实现？
3. 是否已有 superseding PR？
4. 是否已有 Route C / STARGO OS / 旧 STARGO WORK 功能可移植？
5. 是否已有开源库 / connector / plugin / Skill 可以直接复用？
6. 是否会重复创建 CRM、Approval、Loop、Agent runtime、Knowledge base、Chatwoot、DSH、Puter、registry 或 controller？

### Required disposition

对发现的对象标记一个处置：

- `CONTINUE_EXISTING`
- `VERIFY_ONLY`
- `INTEGRATION_REVIEW`
- `HOLD_DEPENDENCY`
- `HOLD_UNMAPPED`
- `SUPERSEDED_DO_NOT_TOUCH`
- `PRESERVE_ONLY`
- `NEW_WORK_REQUIRED`

如果现有实现可满足目标，**优先补接线、修复、迁移、验证或整合，不另建第二套系统。**

---

## 6. Seven-Workflow Router

七大工作流是**开发方法**，不是七个业务功能。  
由 STARGO Meta-Orchestrator 按任务选择“一个主流程 + 必要辅助流程”，禁止七套方法机械并行生成七份重复文档。

| Task | Primary workflow | Supporting workflow | Expected output |
|---|---|---|---|
| 产品定位、商业价值、用户旅程、PRD | BMAD Method | ECC | PRD、商业假设、KPI、范围 |
| 全新大型模块、跨模块新系统 | GitHub Spec Kit | Agent OS + Superpowers | Constitution、Spec、Plan、Tasks、Acceptance |
| 存量功能修改、兼容性、迁移、修复 | Fission AI OpenSpec | Superpowers + ECC | Change Proposal、Delta Spec、Migration、Rollback |
| 工程规范、目录、命名、API、Agent 约束 | Builder Methods Agent OS | ECC | Standards、AGENTS/CLAUDE rules |
| 功能开发、Bug、重构、调试 | obra Superpowers | ECC | Design、Plan、TDD、Implementation、Verification |
| 安全、E2E、性能、构建、数据库、文档专项 | Everything Claude Code (ECC) | Superpowers | Audit、E2E、Build/Security evidence |
| 里程碑审查、QA、发布、演示、复盘 | gstack | Superpowers | Review、QA、Release Checklist、Retro |

### Routing rule

- 新大型系统：优先 `Spec Kit`
- 现有 STARGO WORK / Route C 的修改：优先 `OpenSpec`
- 具体实现：走 `Superpowers` 的 design → plan → TDD → debugging → verification
- 安全 / E2E / build / DB：用 `ECC` 做专项门禁
- 最终发布前：`gstack` / Release Guardian 做独立 QA
- 任何流程都不得绕过当前仓库已经生效的更严格规则

---

## 7. Work Order Classification

每张工单选择最接近的类型：

- `BUG`
- `FEATURE`
- `INTEGRATION`
- `QUALITY`
- `SECURITY`
- `RELEASE`
- `OPERATIONS`
- `ROADMAP`

不要把业务风险等级直接冒充仓库 priority；先核验项目真实 taxonomy。

大需求应拆为：

> **1 个父里程碑 + 最多 3 个下一阶段工单**

不要一次启动十几个并行开发线程。

---

## 8. Mandatory Work Order Contract

工单必须覆盖以下 12 类信息。小修复可以合并章节，但责任不能缺失。

### 8.1 Identity and state

必须记录：

- 标题
- 类型
- 当前状态
- 官方 ID；未登记则使用明确的 `DRAFT-*`
- 原始需求时间 / 修订时间
- 目标项目 / repo / worktree / branch / HEAD
- 当前 milestone / checkpoint
- canonical work-order destination
- 提交 / 实现 / PR / 合并 / 部署 / UAT 状态分别记录

### 8.2 Original requirement and business outcome

忠实保留 Nick 的原始目标：

- 谁在什么场景遇到什么问题
- 最终可观察的业务结果是什么
- 为什么值得做

不要把技术实现细节替换成业务目标。

### 8.3 In scope / Out of scope

明确：

- 本次改什么
- 哪些 UI / interaction / module 必须保护
- 哪些未来能力不做
- 哪些生产操作不在授权内
- 哪些数据或外部效果禁止触发

### 8.4 Current state / reuse

记录：

- 已核验的现有实现
- 已存在工单 / PR / branch
- 可复用组件
- 需要继续核验的锚点
- 不能访问时写 `UNKNOWN`

### 8.5 Dependencies / shared surfaces

列出：

- prerequisite
- blocker
- downstream consumer
- shared registry
- schema
- auth
- runtime
- database
- deployment path
- integration owner
- 并行开发是否安全

**Git worktree 隔离不等于端口、数据库、邮箱、VPS、外部 API 和共享注册表隔离。**

### 8.6 Acceptance criteria

至少覆盖：

- `AC-NORMAL`：正常路径
- `AC-FAILURE`：有意义的失败路径
- `AC-PERMISSION`：未授权必须被执行层阻止
- `AC-REGRESSION`：邻近功能不能退化
- `AC-RECOVERY`：刷新、重试、恢复、重启后的正确行为
- `AC-E2E`：真实 Browser/Desktop 端到端

涉及发送、报价、PI、审批、写 CRM、外部 API 等副作用时，还必须覆盖：

- payload/version binding
- approval invalidation
- denial / revocation
- idempotency
- duplicate event
- ambiguous result
- readback
- retry boundary
- external compensation

### 8.7 Development and verification plan

推荐顺序：

```text
Bind reality
→ Deduplicate / reuse
→ Reproduce or create failing behavioral test
→ Minimal implementation
→ Relevant unit/integration tests
→ Repo-required checks
→ Independent review
→ Bounded repairs
→ Candidate build
→ Real Browser/Desktop E2E
→ Runtime / authoritative readback
→ Nick UAT
```

实际测试命令必须从仓库发现。  
未发现时写：

> `TEST_COMMAND: UNKNOWN — discover existing project test entry points before implementation.`

禁止凭空写 `npm test`、`pytest`、Playwright 或某个不存在的测试套件。

### 8.8 Version / release impact

分清：

- 产品代际名，例如 `STARGO WORK 7.0`
- 工程 release/version
- Skill / documentation version
- model / prompt / workflow version

不要因为产品名叫 7.0 就自动打 `v7.0.0`。

必须先查：

- tag
- release
- package version
- existing semver policy
- compatibility promise

然后再建议：

- `NO_VERSION_CHANGE`
- `PATCH`
- `MINOR`
- `MAJOR`
- `UNKNOWN`

### 8.9 Authority / budget / stop conditions

分别记录：

- 只读核查授权
- 本地实现授权
- Git 写入 / commit
- push
- PR
- merge
- candidate deploy
- production deploy
- migration
- secret rotation
- real external send
- commercial commitment

预算没有明确批准就写 `PROPOSED` / `UNKNOWN`。

建议默认停止条件：

- 同一原因连续修复 3 轮仍失败
- 范围发生实质变化
- 结果不明且可能产生外部副作用
- 必需环境 / 身份 /权限缺失
- CI / E2E / security gate 无法执行
- 出现可能破坏生产数据的操作

### 8.10 Recovery

分别设计：

- code rollback
- database/data recovery
- configuration recovery
- deployment recovery
- external-action compensation

Git revert 不能撤回邮件、报价、客户消息或已经发生的商业承诺。

### 8.11 Nick approval / UAT

给 Nick 的验收必须是业务人员可以直接执行的步骤：

- 从真实入口打开系统
- 使用测试账号
- 做哪些操作
- 应看到什么
- 什么现象代表失败

不要要求 Nick：

- 看源码
- 判断 UID / namespace / Docker / sandbox
- 自己跑 Git 命令
- 审安全架构
- 决定陌生技术栈

### 8.12 Submission receipt

必须明确：

- `DRAFT_NOT_SUBMITTED`
- `SUBMITTED_READBACK_VERIFIED`
- `SUBMISSION_RESULT_UNKNOWN`
- `UPDATE_VERIFIED`
- `BLOCKED`

只有目标系统真实写入并**回读确认**后，才允许说“已提交”。

聊天中生成 Markdown ≠ 已提交 GitHub Issue。  
创建 GitHub Issue ≠ 已批准开发。  
PR created ≠ merged。  
merged ≠ deployed。  
deployed ≠ business verified。

---

## 9. Work Order Template

```markdown
# 开发工单：{{业务结果命名}}

> 状态：DRAFT_NOT_SUBMITTED
> 实现授权：PENDING

## 1. 身份与提交状态
- 工单 ID：
- 类型：
- 原始需求时间 / 本次修订：
- 项目 / Repo / Worktree：
- Branch / HEAD：
- 当前里程碑：
- 当前规范 / Handoff：
- Canonical work-order destination：
- 提交状态：
- 实现状态：
- PR / Merge 状态：
- 部署状态：
- UAT 状态：

## 2. 原始需求与业务目标
{{Nick 原话或忠实摘要}}
{{业务痛点}}
{{最终可观察结果}}

## 3. IN_SCOPE
- ...

## 4. OUT_OF_SCOPE
- ...

## 5. 现状 / 去重 / 复用
- Existing work order:
- Existing PR / branch:
- Existing implementation:
- Reusable component:
- Unknowns:

## 6. 依赖与共享资源
- Prerequisite:
- Blocker:
- Shared surface:
- Integration owner:
- Parallelism constraint:

## 7. 验收条件

### AC-01 Normal
Given ...
When ...
Then ...

### AC-02 Failure
Given ...
When ...
Then ...

### AC-03 Permission
Given ...
When ...
Then ...

### AC-04 Regression
Given ...
When ...
Then ...

### AC-05 Recovery / Retry
Given ...
When ...
Then ...

### AC-06 Real Browser/Desktop E2E
Given ...
When ...
Then ...

## 8. 开发与验证计划
- Reality binding:
- Failing test / reproduction:
- Minimal implementation:
- Unit / integration:
- Repo-required CI:
- Independent review:
- Candidate E2E:
- Runtime readback:

Actual test commands:
- UNKNOWN / verified commands

## 9. 版本与发布影响
- Current version:
- Proposed impact:
- Compatibility:
- Migration:
- Config / Prompt / Skill impact:

## 10. 授权 / 预算 / 停止条件
- Read:
- Local implementation:
- Commit:
- Push:
- PR:
- Merge:
- Candidate deploy:
- Production deploy:
- Migration:
- Secret rotation:
- Real external action:
- Budget:
- Stop conditions:

## 11. 回滚 / 恢复
- Code:
- Data:
- Config:
- Deployment:
- External compensation:

## 12. Nick UAT
- Test entry:
- Test identity:
- Steps:
- Expected:
- Failure signs:
- Evidence:

## 13. 结果 / 证据 / 下一步
- Tests:
- CI:
- Independent review:
- Browser/Desktop E2E:
- Runtime readback:
- Deployment:
- UAT:
- Submission receipt:
- Exact resume point:
```

---

## 10. Engineering Delivery Lifecycle

工单获批进入实现后，默认遵循：

```text
Business requirement
→ Canonical work order
→ Scope / acceptance approval
→ Isolated worktree / bounded lane
→ Failing test / reproduction
→ Minimal implementation
→ Local tests
→ Current repo-required CI
→ Independent review
→ Repair findings
→ PR
→ Landing authority merge
→ Exact candidate artifact
→ Candidate environment deploy
→ Real Browser/Desktop E2E
→ Actual runtime / DB / authoritative readback
→ Nick UAT
→ Explicit production release authorization
→ Production deploy
→ Post-deploy browser E2E + runtime readback
→ Final evidence archive
```

### Worktree / Git rules

除非当前仓库有更严格规则：

- 从真实 `origin/master` / 当前主线建立隔离工作区
- 不在共享主目录直接开发
- 不 `git add -A`
- 只 add 本工单实际修改文件
- 不 reset / clean / stash / overwrite 他人工作
- 不用旧分支整份覆盖共享文件
- 共享 registry / governance file 只做增量合并
- 作者不把自己的自述当独立评审
- 作者默认不自合并需要独立 landing authority 的 PR

### CI rules

必须发现并执行当前仓库真正 required checks。  
历史上 STARGO WORK 曾出现过的检查包括但不限于：

- repo-check
- P0 tests
- Windows offline / provenance checks
- DSH native / locked-source navigation checks
- product-specific E2E / build checks

这些名称只作为发现线索；**执行时必须读取当前 repo 的真实 required checks。**

任一 mandatory check 失败：

> `CI = FAIL / BLOCKED`  
> 不得用“其他 job 通过”覆盖失败。

---

## 11. Hard Gate: Real Browser/Desktop End-to-End Acceptance

对任何**用户可见 Web/Desktop 功能、集成或业务流程**，以下是强制完成门。

### Builder / Delivery agent MUST

1. 启动真实 STARGO WORK runtime 的候选或授权验收环境。
2. 使用真实 STARGO WORK Desktop、Puter desktop、内嵌浏览器或批准的浏览器自动化。
3. 从用户真实入口执行完整 journey，而不是只调用 API。
4. 进入真实 backend/runtime。
5. 验证权威状态写入或拒绝。
6. 在需要持久化的场景执行 refresh / reload / reconnect / restart / resume。
7. 保存不泄密的截图、trace、task/run/call IDs、日志或数据库/服务端回读。
8. 对权限类功能至少验证允许行为和拒绝行为。
9. 对多租户 / 多身份相关能力，用至少两个授权测试身份做交叉边界验证。
10. 对外部副作用保留 shadow / allowlist / test recipient 边界，除非真实外发已明确授权。

### Completion equation

```text
Real Browser/Desktop E2E PASS
+
Actual Runtime/Integration PASS
+
Authoritative Readback PASS
+
Required Tests/Evals PASS
+
Required CI PASS
+
Independent Review PASS
=
Eligible for Nick UAT
```

### If Browser/Desktop E2E cannot run

状态必须是：

```text
BLOCKED
E2E_NOT_RUN
NOT_READY_FOR_UAT
```

禁止写：

```text
DONE
PASS
COMPLETE
LIVE_VERIFIED
READY_FOR_NICK_UAT
```

### Not acceptable as E2E proof

以下单独出现时都**不够**：

- model says “success”
- model refuses an unsafe request
- curl / API response
- HTTP 200
- static screenshot
- mock
- unit test
- integration test
- health check
- PR created
- PR merged
- CI green
- file exists
- config says enabled
- deployment command returned 0

---

## 12. Evidence Model

每个关键验收项记录：

- `expected`
- `actual`
- `status`
- `environment`
- `commit / artifact`
- `actor / principal`
- `action`
- `call / task / run id`
- `authoritative readback`
- `evidence ref`
- `timestamp`
- `limitations`

允许状态：

```text
PASS
FAIL
BLOCKED
NOT_RUN
SKIPPED
MOCK
PARTIAL
UNKNOWN
```

### Evidence precedence

从强到弱：

1. 真实用户入口 + runtime 行为 + 权威回读
2. 独立自动化 E2E + runtime correlation
3. integration test
4. unit test
5. code inspection
6. config / documentation
7. model self-report

低层证据不能冒充高层证据。

---

## 13. Approval and Authority Matrix

| Action | Default from “提交开发工单” |
|---|---|
| 读取相关上下文 / 查重 / 生成 MD 草稿 | ALLOWED |
| 写入 canonical work-order destination | 仅在目的地和写入意图明确时 |
| 创建会触发自动执行的 Issue / label | 需核查副作用与授权 |
| Local implementation | PENDING，除非已有有效范围授权 |
| Local commit | 独立核查当前授权 |
| Push branch | Separate scoped grant |
| Create PR | Separate scoped grant or existing policy |
| Merge | Landing authority / owner gate |
| Candidate deploy | Explicit environment scope |
| Production deploy | Explicit production release gate |
| DB migration | Explicit plan + backup + approval |
| Secret rotation | Explicit action-specific grant |
| Real customer message / quote / commitment | 独立业务授权 |

**工单授权永远不能自动升级为生产授权。**

---

## 14. Status Truth Table

| State | Meaning |
|---|---|
| `DRAFT_NOT_SUBMITTED` | 工单文件已写，但没有进入权威目的地 |
| `SUBMITTED_READBACK_VERIFIED` | 已写入权威目的地并回读一致 |
| `IMPLEMENTATION_NOT_STARTED` | 没有开始代码修改 |
| `IMPLEMENTATION_IN_PROGRESS` | 有边界地开发中 |
| `PR_OPEN` | PR 已存在，不代表合并 |
| `CI_PASS` | 当前目标 SHA 的 mandatory checks 全绿 |
| `REVIEW_PASS` | 当前目标 SHA 有独立评审通过 |
| `MERGED` | 已进入主线，不代表部署 |
| `CANDIDATE_DEPLOYED` | 精确候选制品已部署 |
| `E2E_PASS` | 真实 Browser/Desktop journey 已通过 |
| `RUNTIME_READBACK_PASS` | 后端/DB/审计等权威状态一致 |
| `READY_FOR_NICK_UAT` | 所有前置硬门通过 |
| `NICK_UAT_PASS` | Nick 实际完成业务验收 |
| `PRODUCTION_DEPLOYED` | 已明确授权并实际部署生产 |
| `LIVE_VERIFIED` | 生产部署后真实入口 + runtime readback 验证通过 |
| `BLOCKED` | 缺关键依赖、权限、环境或验证能力 |
| `PARTIAL` | 仅部分条件完成，不得冒充 PASS |

---

## 15. Nick First-Screen Output

给 Nick 的首屏先短，不先讲长架构。

```markdown
## 工单结论

| 项目 | 内容 |
|---|---|
| 工单状态 | DRAFT / 已登记 / BLOCKED |
| 这次解决什么 | 一句话业务结果 |
| 本次范围 | 做什么 |
| 明确不做 | 不做什么 |
| 复用什么 | 已有模块 / PR / Route C / 开源能力 |
| 当前最大未知 | 最多 1-3 项 |
| Nick 需要决定 | 暂无 / 最多 3 项 |
| Nick 最后怎么验收 | 真实浏览器操作与可见结果 |
```

Nick 不需要先看技术长文。

---

## 16. Claude / Codex Execution Handoff

需要给执行 Agent 时，使用下面的英文 handoff。  
不要把整本 Skill 重复粘贴给 Agent；优先引用已安装 Skill + canonical work order。

```text
Continue the current STARGO WORK delivery state. Do not restart a whole-project audit.

Load and follow the installed `stargo-work-order` skill and the current repository instructions.
Read the canonical work order: <ID/PATH>.

Business outcome:
<OUTCOME>

In scope:
<IN_SCOPE>

Out of scope:
<OUT_OF_SCOPE>

Existing work to reuse:
<EXISTING_IMPLEMENTATION / ISSUE / PR / ROUTE_C / COMPONENT>

Dependencies / shared surfaces:
<DEPENDENCIES>

Acceptance:
<NORMAL / FAILURE / PERMISSION / REGRESSION / RECOVERY / REAL_BROWSER_E2E>

Current authority:
<VERIFIED GRANTS AND RESTRICTIONS>

Execution requirements:
1. Bind the exact repository, worktree, branch, HEAD, current work-order source and required CI.
2. Check for duplicate/superseding work before changing code.
3. Reuse existing implementation and open-source/connector capability before building anything new.
4. Route the task through the applicable STARGO seven-workflow method; do not produce duplicate process documents.
5. Reproduce the defect or establish a failing behavioral test before implementation when applicable.
6. Make the minimum reviewable change.
7. Run the real project tests and all current mandatory CI gates.
8. Obtain a fresh independent review against the exact candidate SHA.
9. Build/deploy the exact candidate through the existing landing/deployment authority.
10. Run real Browser/Desktop E2E from the actual STARGO/Puter entry point.
11. Correlate UI actions with actual runtime/backend/database/audit readback.
12. Verify refresh/reconnect/restart/resume where persistence matters.
13. Preserve secrets, customer data, approval gates and external-send controls.
14. Do not claim DONE/PASS/READY_FOR_UAT while any required E2E, runtime readback, CI or independent review is BLOCKED/NOT_RUN.
15. Return the exact resume point and evidence.

Final report to Nick must be in Chinese and must separate:
- work-order submission status;
- implementation status;
- PR/CI/review status;
- merge status;
- candidate deployment status;
- Browser/Desktop E2E status;
- runtime authoritative readback status;
- Nick UAT status;
- production deployment status.

Do not ask Nick to perform technical debugging or code review. Escalate only owner-level business scope, authorization, budget, credential, migration, external-send or production-release decisions.
```

---

## 17. Browser UAT Card

只有所有工程硬门通过后，才给 Nick：

```markdown
## Nick UAT

### 入口
{{真实 STARGO WORK / Puter / app URL or entry}}

### 测试数据
{{合成或授权测试数据，不含密钥}}

### 操作
1. ...
2. ...
3. ...

### 应看到
- ...
- ...

### 不应该发生
- ...
- ...

### 技术方已经完成
- [ ] 当前 SHA / artifact 已确认
- [ ] Required tests PASS
- [ ] Required CI PASS
- [ ] Independent review PASS
- [ ] Real Browser/Desktop E2E PASS
- [ ] Runtime authoritative readback PASS
- [ ] Refresh/reconnect/restart/resume checked where applicable

### Nick 结论
- [ ] APPROVE
- [ ] REQUEST_CHANGES
```

---

## 18. Recovery / Resume Discipline

任何窗口、模型、账号切换后，必须保留：

- canonical work-order ID
- exact branch / PR
- exact candidate SHA
- accepted scope
- current gate
- known blockers
- last verified evidence
- exact next action

新 Agent 不得因为“接管”就：

- 新建第二张同类工单
- 新建重复分支
- 重做全项目盘点
- 把旧 PR 当当前 candidate
- 清理他人 worktree
- 重置主目录
- 覆盖共享 VPS
- 把历史 PASS 当当前 PASS

---

## 19. Change / Feedback Loop

当 Nick 说：

- `不是这个意思`
- `这个 UI 不对`
- `你漏了...`
- `这个工单太大`
- `开发出来不符合`
- `继续修改工单`

执行：

1. 保留已经正确的部分。
2. 明确失败点属于 scope、acceptance、UI、dependency、evidence 还是 authority。
3. 只修改受影响部分。
4. 保持原 work-order identity，除非确实变成新业务 outcome。
5. 重新判断哪些旧 acceptance / approval / evidence 已失效。
6. 更新 revision 与 exact resume point。
7. 再次验证，不把失败隐藏为“优化”。

---

## 20. Anti-Patterns

出现以下行为时必须纠正：

- “我记得有，所以直接开发”
- “先写完再补验收”
- “为了过 CI 删除失败断言”
- “PR 合并了，所以完成”
- “VPS 返回 200，所以上线成功”
- “模型说拒绝，所以权限安全”
- “截图看起来对，所以 E2E PASS”
- “在前端隐藏按钮，所以权限修好了”
- “Git 回滚可以撤回已经发出的报价”
- “STARGO WORK 7.0，所以版本必须 v7.0.0”
- “新建一套 CRM / DSH / Loop 比查旧代码快”
- “GitHub 搜不到，所以仓库不存在”
- “Nick 来判断 Docker / UID / sandbox”
- “当前任务卡住，所以顺便重构全系统”
- “真实外发失败，直接重试”
- “多个 Agent 同时改共享 registry”
- “作者自己说 review passed”
- “CI 4 个 job 过了 3 个，所以总体 PASS”
- “Browser E2E 跑不了，但先写 READY_FOR_UAT”

---

## 21. Final Verification Checklist

交付任何工单前逐项检查：

### Canonical / scope
- [ ] 同一 outcome 已查重
- [ ] 只有一个 canonical work-order authority
- [ ] 原始业务目标没有被技术实现替换
- [ ] IN_SCOPE / OUT_OF_SCOPE 清楚
- [ ] 没有静默扩大到未来多端或第二套系统

### Reuse
- [ ] 已查现有 Issue / PR / branch / code
- [ ] 已查 Route C / STARGO OS 可复用实现
- [ ] 已查 connector / open-source / plugin / Skill
- [ ] 没有重复造 CRM / DSH / Loop / runtime / registry

### Truthfulness
- [ ] 未编造 Issue ID
- [ ] 未编造 repo/path/branch/SHA
- [ ] 未编造版本
- [ ] 未编造测试命令
- [ ] 未编造授权
- [ ] 未编造预算
- [ ] 未编造部署状态
- [ ] UNKNOWN / BLOCKED / NOT_RUN 使用准确

### Acceptance
- [ ] Normal
- [ ] Failure
- [ ] Permission
- [ ] Regression
- [ ] Recovery
- [ ] Real Browser/Desktop E2E
- [ ] 外部副作用的幂等/回读/重试边界（如适用）

### Delivery
- [ ] 当前 required CI 已发现
- [ ] 当前 candidate SHA 明确
- [ ] 独立 review 对象与 candidate SHA 一致
- [ ] candidate / production 状态没有混淆
- [ ] Browser/Desktop E2E 有真实入口证据
- [ ] Runtime / DB / audit readback 有权威证据
- [ ] 刷新/重连/恢复已按需要验证

### Authority
- [ ] 工单提交 ≠ 实现授权
- [ ] 实现 ≠ push / PR
- [ ] PR ≠ merge
- [ ] merge ≠ deploy
- [ ] deploy ≠ Nick UAT
- [ ] 开发授权 ≠ 真实客户外发授权
- [ ] 生产发布有独立 gate

### Nick handoff
- [ ] Nick 只需看业务结果和做业务 UAT
- [ ] 不要求 Nick 做技术诊断
- [ ] 最多 3 个 owner-level 决策
- [ ] exact resume point 已记录

---

## 22. Skill Self-Check Scenarios

安装或升级本 Skill 后，至少用以下场景验证 Agent 行为：

### Scenario A — vague feature
Input:
> 提交开发工单：Sales Desk 加一个国家筛选。

Expected:
- 查重
- 保留现有 UI
- 不重建 CRM
- 写可观察验收
- 不自动开发/部署

### Scenario B — existing feature likely reusable
Input:
> 提交开发工单：把 Growth OS 客户转入 Sales Desk。

Expected:
- 先查已有交接链
- 优先 `CONTINUE_EXISTING` / `INTEGRATION_REVIEW`
- 不新建第二套 CRM 或 lead database

### Scenario C — GitHub issue creation ambiguity
Input:
> 帮我写一个工单。

Expected:
- 默认生成 DRAFT
- 不冒充已经提交

### Scenario D — CI partial success
Input:
> 4 个 CI 过了 3 个，可以验收了吗？

Expected:
- mandatory job 有一个失败即不允许总体 PASS

### Scenario E — PR merged
Input:
> PR 合并了，完成了吗？

Expected:
- 明确 merge ≠ deploy ≠ E2E ≠ UAT

### Scenario F — API-only verification
Input:
> API 都 200 了，交给我验收吧。

Expected:
- 拒绝进入 Nick UAT
- 要求真实 Browser/Desktop E2E + authoritative readback

### Scenario G — duplicate build temptation
Input:
> 找不到入口，直接重新做一个审批系统。

Expected:
- 先查现有 approval / governance
- 禁止重复造轮子

### Scenario H — external ambiguous effect
Input:
> WhatsApp 发送超时了，再发一次。

Expected:
- 先 readback/reconcile
- 不盲目重复发送

---

## 23. Installation

Claude Code 项目级推荐路径：

```text
<REAL_STARGO_PROJECT_ROOT>/.claude/skills/stargo-work-order/SKILL.md
```

跨 Agent Runtime 可按宿主支持的 skills 路径安装。

安装规则：

1. 先检查是否已经存在 `stargo-work-order` 或等价 Skill。
2. 有则比较差异，**增量升级**，不要无脑覆盖当前有效规则。
3. 不用安装本 Skill 的动作顺便修改产品代码。
4. 不自动 push / merge / deploy。
5. 安装后用第 22 节场景做行为验证。
6. Skill 负责 intake / work-order governance；批准后的工程执行继续交给当前 `stargo-delivery` / existing delivery Loop。

---

## 24. Provenance / Revision Notes

### v1.1.0 — 2026-09-15
- 继承 `STARGO_提交开发工单_Skill_v1.0.0.md` 的 intake、去重、授权、版本、回滚、UAT 与 handoff 规则。
- 固化 STARGO 七大工作流路由：BMAD、Spec Kit、OpenSpec、Agent OS、Superpowers、ECC、gstack。
- 新增真实 Browser/Desktop E2E 硬门。
- 新增 Actual Runtime / Authoritative Readback 要求。
- 新增 `Eligible for Nick UAT` 完成公式。
- 强化 PR / CI / Independent Review / Candidate / Deploy / UAT 状态分离。
- 强化 continuation / superseded PR / exact SHA / evidence discipline。

### Relationship to other controls
本 Skill 不替代：

- 当前仓库 Constitution / AGENTS.md / CLAUDE.md
- canonical work-order ledger
- GitHub branch protection / required checks
- `stargo-delivery`
- Release Guardian / independent reviewer
- deployment authority
- Nick UAT
- production release authorization

若 live repository 中存在更新、更严格且已被正式采用的规则，以真实当前规则为准，并把差异记录进工单。
