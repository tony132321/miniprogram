# 授权矩阵

授权有project/repo、action、paths/resources、environment、actor、payload/version（如适用）、not_before/expires_at、budget和来源凭证。状态JSON不能自己给自己授权。

|动作|本包初始状态|核准规则|
|---|---|---|
|审查与生成本开发包|本次用户已要求|仅当前交付产物|
|目标仓库只读核查|需明确目标|不能猜仓库或借用STARGO授权|
|本地隔离R1实现/合成数据测试|PENDING|用户发送范围启动授权后记录；受live repo规则限制|
|创建本地隔离分支/commit|PENDING|可在一次性启动授权中明确；只改本工单文件、不全量git add|
|push/PR/merge|NOT_AUTHORIZED|分别核对已有正式策略或明确授予|
|本地临时测试DB schema|PENDING|只在明确隔离测试授权内，不涉及任何共享/生产库|
|远程candidate部署|NOT_AUTHORIZED|精确环境、资源、版本与测试收件人范围|
|生产部署/迁移/密钥|NOT_AUTHORIZED|专项计划、备份、回退、目标身份和新批准|
|真实通知/短信/付费AI|NOT_AUTHORIZED|渠道/收件人/个人数据/模板/费用范围与同意|
|付款/退款/订场|NOT_AUTHORIZED|R2闸门另行开启；R1禁止|
|未来阶段/新增业务范围|CLOSED|产品、平台、安全、预算分别通过|

后端业务权限独立于开发Agent工具权限。Agent得到开发权，不代表能代参与者报名、接受费用或批准主办行为。
用户在任意时刻暂停/撤权后，新调度立即停止相关动作；已发生效果先核对，不能盲重试。
