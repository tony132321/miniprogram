# Project IRL · 自动化工程开发包 v3.1

**交付对象：Codex / Claude Code / 能读本地文件的代码 Agent。**
**本次完成：开发包审查、补全与本地控制工具验证。不是小程序实现、已提交工单、平台审核或生产发布。**

先读 `00_START_HERE.md`。审查证据见 `02_AUDIT_REPORT.md` 和 `audit/V3_AUDIT_EVIDENCE.json`。

## 保留与修复

完整保留 PRD v1.0 和用户指定的 stargo-work-order v1.1.0 原文；保留 v3 的父工单 ID `DRAFT-IRL-AUTO-003` 与 T01–T35，不另建重复需求。
R1 仍是原生微信小程序＋Web 运营后台。RQ18 隐私正式纳入；RQ16/RQ17 保留为有明确激活条件的后续范围。
UI 保留 Apple 式清晰、留白、精致控件＋Partiful 式活动海报和卡片，不复制其商标/素材。

## 三件不同的事

- Goal 是原生代码 Agent 会话中的目标命令；完整约束在文件内，不塞进超长 slash command。
- Graph 是可审查的项目内工程契约，不是安装即运行的软件服务。本包不会另建 agent runtime。
- Bounded repair 是节点内部有限修复；Claude `/loop` 另作有上限的只读监控，不能同时成为第二个代码 writer，也不能代替产品通知/候补的持久队列。

`governance/STATUS.json` 是唯一可变运行状态源。任务、需求、Graph、页面和验收 JSON 是规格，不另存竞争状态。
本包的校验工具不调用模型、不启动应用、不发送消息、不安装依赖、不改全局设置、不部署。

## 完成层次

1. `PACKAGE_STRUCTURE_PASS`：包内引用/结构自洽。
2. `LOCAL_IMPLEMENTATION_VERIFIED`：目标仓库的本地实现测试与评审通过；仍不等于真实集成。
3. `READY_FOR_NICK_UAT`：候选版本绑定的 required tests/CI、独立评审、微信开发工具、真机、后台浏览器 E2E、权限安全、权威回读等全部满足。
4. `PILOT_READY`：Nick 业务 UAT 及试点主体/账号/数据/运营/授权闸门通过。
5. `PUBLIC_R1_READY`：另完成至少三场受控真实活动、问题关闭与正式发布批准。

没有设备不能豁免真机；没有第三方凭证可继续独立的本地开发，但相应集成保持 BLOCKED。
软件验收尚未执行。不得把本包的 Python 测试结果填入产品的 required_tests / CI / E2E 门禁。

## 主要文件

`engineering/backlog.json`：35个依赖驱动任务；`engineering/tasks/`：逐任务实施契约。
`specs/acceptance_cases.json`：127条具体验收规格，不是127个已经运行的应用测试。
`specs/requirements.json`：20个RQ＋12个跨域要求；`design/pages.json`：全部12个PRD页面，其中11个R1、PG11后续关闭。
`specs/openapi.json`：目标接口草案；`specs/TRANSACTIONS_AND_JOBS.md`：并发、版本和副作用规则。
`governance/GATE_POLICY.json`：阶段准入；`environment/`：真实能力与依赖核验。
`scripts/`：离线包检查、证据结构检查、checkpoint CAS、就绪队列和环境只读探测。
`roadmap/`：未来版本和真实发布授权，而非偷偷加入R1。

## 约束优先级不是一张混合排名

业务范围由用户明确决策和 PRD 约束；工程安全由 live repo 的正式规则与开发工单 Skill 约束；实际执行状态由 STATUS 与证据约束。
STATUS、模型输出或工程计划不能改写 PRD。发生冲突先记录影响和 owner 决策，不自动选择更方便的一方。

日期：2026-09-25。官方能力核验来源与失败边界见 `sources/VERIFICATION.md`。
