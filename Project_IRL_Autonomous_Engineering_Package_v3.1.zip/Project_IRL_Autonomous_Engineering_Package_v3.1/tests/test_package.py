"""Package/control-contract tests only. Synthetic receipts below are NOT product evidence."""
import copy, hashlib, json, os, shutil, sys, tempfile, unittest
from datetime import datetime, timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from package_lib import check_package, gate_errors, receipt_errors, safe_path, ready_batch
from state_io import update_state, StateConflict, StateLocked

def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

class PackageTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)/'pkg'
        shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    def tearDown(self):self.tmp.cleanup()
    def edit(self,p,fn):
        d=json.loads((self.root/p).read_text());fn(d);dump(self.root/p,d)
    def has(self,text): self.assertTrue(any(text in x for x in check_package(self.root)),check_package(self.root))
    def test_baseline_structure(self):self.assertEqual([],check_package(self.root))
    def test_invalid_json(self):
        (self.root/'specs/acceptance_cases.json').write_text('{bad');self.has('JSON')
    def test_duplicate_json_key(self):
        (self.root/'design/tokens.json').write_text('{"x":1,"x":2}');self.has('duplicate JSON key')
    def test_undefined_acceptance(self):
        self.edit('engineering/backlog.json',lambda d:d['items'][0]['acceptance'].append('AC-MISSING'));self.has('undefined acceptance')
    def test_duplicate_task(self):
        self.edit('engineering/backlog.json',lambda d:d['items'].append(d['items'][0]));self.has('duplicate task')
    def test_cycle(self):
        self.edit('engineering/backlog.json',lambda d:d['items'][0]['depends_on'].append('T35'));self.has('dependency cycle')
    def test_missing_dependency(self):
        self.edit('engineering/backlog.json',lambda d:d['items'][1]['depends_on'].append('T99'));self.has('undefined dependency')
    def test_missing_rq18(self):
        self.edit('specs/requirements.json',lambda d:d.update(items=[r for r in d['items'] if r['id']!='RQ18']));self.has('RQ18')
    def test_requirement_without_acceptance(self):
        self.edit('specs/requirements.json',lambda d:d['items'][0].update(acceptance_ids=[]));self.has('uncovered requirement')
    def test_empty_then(self):
        self.edit('specs/acceptance_cases.json',lambda d:d['cases'][0].update(then=[]));self.has('empty acceptance')
    def test_goal_too_long(self):
        (self.root/'codex/GOAL_COMMAND.txt').write_text('/goal '+'x'*4001);self.has('goal length')
    def test_graph_frontmatter(self):
        p=self.root/'.codex/graphs/irl-r1-build.md';p.write_text(p.read_text().replace('schema: graph-engineering/v1','schema: wrong'));self.has('graph schema')
    def test_graph_missing_end(self):
        p=self.root/'.codex/graphs/irl-r1-build.md';p.write_text(p.read_text().replace('| terminal | END |','| terminal | missing |'));self.has('graph')
    def test_missing_graph(self):
        (self.root/'.codex/graphs/irl-r1-build.md').unlink();self.has('missing file')
    def test_nav_unknown_page(self):
        self.edit('design/navigation.json',lambda d:d['edges'][0].update(to='PG99'));self.has('navigation')
    def test_future_flag(self):
        self.edit('environment/FEATURE_FLAGS.json',lambda d:d['flags']['merchant_payments'].update(default=True));self.has('future flag')
    def test_prd_tampering(self):
        p=self.root/'01_PRD_v1.0.md';p.write_text(p.read_text()+'\nchanged');self.has('source hash')
    def test_fake_uat_claim(self):
        self.edit('governance/STATUS.json',lambda d:d.update(run_state='READY_FOR_NICK_UAT'));self.has('unsubstantiated status')
    def test_fake_single_gate_pass(self):
        self.edit('governance/STATUS.json',lambda d:d['gates']['required_ci'].update(status='PASS'));self.has('PASS without evidence')
    def test_duplicate_phase_assignment(self):
        self.edit('work_orders/index.json',lambda d:d['orders'][1]['task_ids'].append('T01'));self.has('work-order partition')
    def test_openapi_dangling_reference(self):
        self.edit('specs/openapi.json',lambda d:d['components']['schemas']['Receipt']['properties'].update(bad={'$ref':'#/components/schemas/NOPE'}));self.has('API reference')
    def test_gate_initially_denied(self):self.assertTrue(gate_errors(self.root,'nick_uat'))
    def test_unknown_gate_denied(self):self.assertTrue(gate_errors(self.root,'invented'))
    def test_no_parallel_conflicting_domain(self):
        tasks=[{'id':'A','depends_on':[],'write_domain':'db','resource_locks':[],'write_paths':['src/a']},{'id':'B','depends_on':[],'write_domain':'db','resource_locks':[],'write_paths':['src/b']}]
        self.assertEqual(['A'],ready_batch(tasks,{},3))
    def test_parent_child_path_conflict(self):
        tasks=[{'id':'A','depends_on':[],'write_domain':'a','resource_locks':[],'write_paths':['src']},{'id':'B','depends_on':[],'write_domain':'b','resource_locks':[],'write_paths':['src/users']}]
        self.assertEqual(['A'],ready_batch(tasks,{},3))
    def test_dependency_ready_only(self):
        tasks=[{'id':'A','depends_on':[]},{'id':'B','depends_on':['A']}]
        self.assertEqual(['A'],ready_batch(tasks,{},3));self.assertEqual(['B'],ready_batch(tasks,{'A':{'status':'LOCAL_VERIFIED'}},3))
    def test_blocked_lane_does_not_block_independent(self):
        self.assertEqual(['B'],ready_batch([{'id':'A','depends_on':[]},{'id':'B','depends_on':[]}],{'A':{'status':'BLOCKED'}},3))

class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        (self.root/'evidence/product').mkdir(parents=True)
        artifact=self.root/'evidence/product/result.txt';artifact.write_text('SYNTHETIC UNIT TEST FIXTURE; NOT REAL EVIDENCE')
        self.state={'candidate':{'id':'test-candidate','content_digest':'a'*64,'author_ids':['maker'],'frozen_at':'2026-09-24T00:00:00+00:00'}}
        self.policy={'gate_types':{'independent_review':['independent_review'],'required_ci':['ci_run'],'real_device_e2e':['real_device'],'three_real_pilots':['real_pilot'],'nick_business_uat':['human_uat']}}
        self.receipt={'schema':'project-irl/evidence-v1','id':'test-evidence','gate':'independent_review','status':'PASS','kind':'independent_review','candidate_id':'test-candidate','candidate_digest':'a'*64,'environment':{'kind':'candidate','target':'synthetic-fixture'},'actor':{'id':'reviewer','role':'independent_reviewer','session_id':'review-session'},'observed_at':'2026-09-25T00:00:00+00:00','checks':[{'id':'fixture-check','status':'PASS'}],'artifacts':[{'path':'evidence/product/result.txt','sha256':sha(artifact)}],'limitations':['SYNTHETIC UNIT TEST ONLY'],'read_only':True,'candidate_unchanged':True}
    def tearDown(self):self.tmp.cleanup()
    def err(self,gate='independent_review'):return receipt_errors(self.root,self.receipt,gate,self.state,self.policy)
    def test_well_formed_receipt_contract(self):self.assertEqual([],self.err())
    def test_self_review_rejected(self):self.receipt['actor']['id']='maker';self.assertTrue(self.err())
    def test_wrong_digest(self):self.receipt['candidate_digest']='b'*64;self.assertTrue(self.err())
    def test_stale_receipt(self):self.receipt['observed_at']='2026-09-23T00:00:00+00:00';self.assertTrue(self.err())
    def test_changed_artifact(self):(self.root/'evidence/product/result.txt').write_text('changed');self.assertTrue(self.err())
    def test_missing_artifact(self):(self.root/'evidence/product/result.txt').unlink();self.assertTrue(self.err())
    def test_failed_check(self):self.receipt['checks'][0]['status']='FAIL';self.assertTrue(self.err())
    def test_empty_checks(self):self.receipt['checks']=[];self.assertTrue(self.err())
    def test_mock_receipt(self):self.receipt['environment']['kind']='mock';self.assertTrue(self.err())
    def test_unsafe_artifact_path(self):self.receipt['artifacts'][0]['path']='../secret';self.assertTrue(self.err())
    def test_absolute_path(self):
        with self.assertRaises(ValueError):safe_path(self.root,'/etc/passwd')
    def test_symlink_path(self):
        (self.root/'evidence/product/link').symlink_to(self.root/'evidence/product/result.txt');self.receipt['artifacts'][0]['path']='evidence/product/link';self.assertTrue(self.err())
    def test_validation_not_product_evidence(self):
        p=self.root/'validation/proof';p.parent.mkdir();p.write_text('fixture');self.receipt['artifacts']=[{'path':'validation/proof','sha256':sha(p)}];self.assertTrue(self.err())
    def test_ci_partial_failure(self):
        self.receipt.update(gate='required_ci',kind='ci_run',required_jobs=[{'name':'unit','status':'PASS'},{'name':'security','status':'FAIL'}]);self.assertTrue(self.err('required_ci'))
    def test_real_device_requires_device_identity(self):
        self.receipt.update(gate='real_device_e2e',kind='real_device');self.assertTrue(self.err('real_device_e2e'))
    def test_pilot_requires_real_fields(self):
        self.receipt.update(gate='three_real_pilots',kind='real_pilot');self.assertTrue(self.err('three_real_pilots'))
    def test_ai_cannot_be_human_uat(self):
        self.receipt.update(gate='nick_business_uat',kind='human_uat');self.assertTrue(self.err('nick_business_uat'))

class StateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        dump(self.root/'governance/STATUS.json',{'schema':'project-irl/status-v2','state_revision':0,'value':1})
    def tearDown(self):self.tmp.cleanup()
    def test_cas_revision(self):
        out=update_state(self.root,0,lambda s:{**s,'value':2},'unit-test');self.assertEqual(1,out['state_revision']);self.assertEqual(2,out['value'])
    def test_old_revision_rejected(self):
        update_state(self.root,0,lambda s:s,'unit-test')
        with self.assertRaises(StateConflict):update_state(self.root,0,lambda s:s,'unit-test')
    def test_live_lock_not_stolen(self):
        (self.root/'governance/STATUS.json.lock').write_text('active writer')
        with self.assertRaises(StateLocked):update_state(self.root,0,lambda s:s,'unit-test')
    def test_transform_failure_preserves_original(self):
        before=(self.root/'governance/STATUS.json').read_bytes()
        def bad(s):raise RuntimeError('intentional')
        with self.assertRaises(RuntimeError):update_state(self.root,0,bad,'unit-test')
        self.assertEqual(before,(self.root/'governance/STATUS.json').read_bytes());self.assertFalse((self.root/'governance/STATUS.json.lock').exists())
    def test_reject_schema_change(self):
        with self.assertRaises(ValueError):update_state(self.root,0,lambda s:{**s,'schema':'different'},'unit-test')
    def test_symlink_state_denied(self):
        p=self.root/'governance/STATUS.json';other=self.root/'copy';p.rename(other);p.symlink_to(other)
        with self.assertRaises(ValueError):update_state(self.root,0,lambda s:s,'unit-test')

if __name__=='__main__':unittest.main()
