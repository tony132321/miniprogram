"""Extra adversarial contract tests. Every receipt is an isolated synthetic fixture."""
import hashlib,json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from package_lib import gate_errors,check_package,receipt_errors,load

def put(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

class GateContractTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.r=Path(self.tmp.name)
        code=self.r/'app/source';code.parent.mkdir();code.write_text('SYNTHETIC TEST ONLY')
        manifest=self.r/'evidence/product/candidate.json';put(manifest,{'candidate_id':'c1','files':[{'path':'app/source','sha256':sha(code)}]})
        log=self.r/'evidence/product/run.log';log.write_text('UNIT-TEST FIXTURE. Not CI proof.')
        self.receipt={'schema':'project-irl/evidence-v1','id':'e1','gate':'required_tests','status':'PASS','kind':'test_run','candidate_id':'c1','candidate_digest':sha(manifest),'environment':{'kind':'integration','target':'fixture'},'actor':{'id':'runner','role':'test_runner','session_id':'fixture-session'},'observed_at':'2026-09-25T00:00:00+00:00','checks':[{'id':'AC-FIXTURE','status':'PASS'}],'artifacts':[{'path':'evidence/product/run.log','sha256':sha(log)}],'limitations':['SYNTHETIC FIXTURE NOT REAL PRODUCT EVIDENCE']}
        self.state={'repo':{'root':str(self.r)},'candidate':{'id':'c1','content_digest':sha(manifest),'manifest_ref':'evidence/product/candidate.json','frozen_at':'2026-09-24T00:00:00+00:00','author_ids':['maker']},'gates':{'required_tests':{'status':'PASS','evidence_refs':['evidence/product/test.json']}}}
        self.policy={'gate_types':{'required_tests':['test_run']},'stage_gates':{'nick_uat':['required_tests']},'required_case_ids':{'required_tests':['AC-FIXTURE']}}
        self.save()
    def tearDown(self):self.tmp.cleanup()
    def save(self):
        put(self.r/'governance/STATUS.json',self.state);put(self.r/'governance/GATE_POLICY.json',self.policy);put(self.r/'evidence/product/test.json',self.receipt)
    def test_synthetic_contract_positive_control(self):self.assertEqual([],gate_errors(self.r,'nick_uat'))
    def test_missing_required_case(self):self.receipt['checks'][0]['id']='OTHER';self.save();self.assertTrue(any('missing case coverage' in x for x in gate_errors(self.r,'nick_uat')))
    def test_candidate_source_drift(self):(self.r/'app/source').write_text('drift');self.assertTrue(any('candidate file changed' in x for x in gate_errors(self.r,'nick_uat')))
    def test_candidate_manifest_drift(self):(self.r/'evidence/product/candidate.json').write_text('{}');self.assertTrue(gate_errors(self.r,'nick_uat'))
    def test_missing_repo_binding(self):self.state['repo']['root']=None;self.save();self.assertTrue(gate_errors(self.r,'nick_uat'))
    def test_missing_author_identity(self):self.state['candidate']['author_ids']=[];self.save();self.assertTrue(gate_errors(self.r,'nick_uat'))
    def test_status_only_pass_not_receipt(self):self.state['gates']['required_tests']['evidence_refs']=[];self.save();self.assertTrue(gate_errors(self.r,'nick_uat'))
    def test_corrupt_receipt(self):(self.r/'evidence/product/test.json').write_text('{');self.assertTrue(gate_errors(self.r,'nick_uat'))
    def test_duplicate_pilots_do_not_count_three(self):
        self.policy={'gate_types':{'three_real_pilots':['real_pilot']},'stage_gates':{'nick_uat':['three_real_pilots']},'required_case_ids':{}}
        self.state['gates']={'three_real_pilots':{'status':'PASS','evidence_refs':['evidence/product/test.json']*3}}
        self.receipt.update(gate='three_real_pilots',kind='real_pilot',real_activity=True,synthetic=False,activity_id='same-activity',independent_participant_evidence=['fixture']);self.save()
        self.assertTrue(any('fewer than 3' in x for x in gate_errors(self.r,'nick_uat')))
    def test_missing_ci_required_set(self):
        self.policy={'gate_types':{'required_ci':['ci_run']},'stage_gates':{'nick_uat':['required_ci']},'required_case_ids':{}}
        self.state['gates']={'required_ci':{'status':'PASS','evidence_refs':['evidence/product/test.json']}}
        self.receipt.update(gate='required_ci',kind='ci_run',required_jobs=[{'name':'unit','status':'PASS'}]);self.save()
        self.assertTrue(any('required check binding' in x for x in gate_errors(self.r,'nick_uat')))
    def test_ci_missing_declared_job(self):
        self.policy={'gate_types':{'required_ci':['ci_run']},'stage_gates':{'nick_uat':['required_ci']},'required_case_ids':{}}
        self.state['gates']={'required_ci':{'status':'PASS','evidence_refs':['evidence/product/test.json']}}
        self.receipt.update(gate='required_ci',kind='ci_run',required_jobs=[{'name':'unit','status':'PASS'}]);self.save()
        put(self.r/'environment/COMMAND_BINDINGS.json',{'required_check_names':['unit','security'],'required_checks_source_ref':'evidence/product/run.log'})
        self.assertTrue(any('required CI coverage' in x for x in gate_errors(self.r,'nick_uat')))

class ProviderContractTests(unittest.TestCase):
    def test_missing_live_integration_inventory_rejected(self):
        # Use the positive fixture setup, but request a provider-integration gate.
        f=GateContractTests();f.setUp()
        try:
            f.receipt.update(gate='provider_integrations',kind='provider_integration')
            p={'gate_types':{'provider_integrations':['provider_integration']}}
            self.assertTrue(any('integration' in e for e in receipt_errors(f.r,f.receipt,'provider_integrations',f.state,p)))
        finally:f.tearDown()

if __name__=='__main__':unittest.main()
