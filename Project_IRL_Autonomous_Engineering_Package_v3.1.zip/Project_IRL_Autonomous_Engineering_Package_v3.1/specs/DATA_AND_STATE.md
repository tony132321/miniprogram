# 领域实体与状态不变量

本规格细化PRD第18章；字段具体SQL类型/迁移语法由真实项目ADR确定。所有资源用不可枚举公开标识，内部主键不得成为访问授权。

|实体|最小持久字段|约束|
|---|---|---|
|User|id,state,adult_admission_result,display_name|可选昵称头像；不假装登录=成年核验|
|Consent|user,purpose,scope,policy_version,granted_at,revoked_at|按目的独立；撤回即阻止新效果|
|Event|id,host_id,current_version,lifecycle,moderation,recruitment_open,risk,revision|生命周期、审核、招募、风险各自独立|
|EventVersion|event,version,immutable_facts,created_by,payload_hash|时间/场馆/费用/规则历史不覆盖|
|VenueEvidence|source_type,source_ref,verified_at,expires_at|地图/主办确认/接口确认不同事实|
|Registration|event,user,status,accepted_version,revision,joined_at|每用户每活动唯一有效状态；签到另存|
|Reservation/Offer|event,token_hash,expires_at,status,claimed_by,fence|token不明文进日志；原子认领/释放|
|Outbox/NotificationJob|event_id,dedupe_key,due_at,version,consent_version,status,lease,fence|业务提交同事务，消费者幂等|
|CheckIn/Outcome|event,user,evidence_type,occurred_at,dispute,host_statement|扫码不等于绝对到场；争议可回补|
|Expense/Confirmation|event,version,total_fen,allocation,side,actor|整数分总额一致；两方确认分离|
|Report/Appeal|scope,severity,assigned_operator,evidence,decision,expiry|投诉不可向主办方泄露举报人/不必要内容|
|AIAction/Audit|actor,scope,version,input_hash,actual_receipt,call_id|日志脱敏；不能用自然语言成功替代DB|
|DeletionTombstone|subject,scope,request_id,effective_at,retention_reason|备份恢复重放删除标记|

活动：DRAFT → RECRUITING → CONFIRMED → IN_PROGRESS → COMPLETED；开始前可EXPIRED/CANCELLED。重大变更允许CONFIRMED回RECRUITING（清晰暂停+新同意）；COMPLETED仅表示结项，不自动进入可信完成指标。不得直接任意patch生命周期。

报名：REQUESTED/INTERESTED/WAITLISTED/OFFERED/CONFIRMED/RECONFIRM_REQUIRED/CANCELLED/EXPIRED/REJECTED/REMOVED；允许边按业务动作定义并单测，禁止任意客户端设置status。删除个人资料不删除他人必要活动事实；去标识、受限保留、法定/争议保留分别处理。
