# 事务、时间与持久任务契约

## 1. 容量的唯一事实源
关系数据库保存所有有效占用；缓存不裁决席位。每次报名、审批、认领、退出、补位接受/到期及版本变更在短事务中锁定同一活动容量行，随后读最新事件版本/授权/截止时间，再执行确定性更新。建议数据库唯一约束 `(event_id,user_id)`（有效报名语义按当前架构实现）、唯一有效 offer/seat token、唯一幂等键及唯一业务事件键。

`occupied = CONFIRMED + RECONFIRM_REQUIRED holds + unexpired OFFERED holds + unexpired host reservations`，永远不大于 max。`formation_count` 仅计算当前版本已确认的独立真实账号。主办方只有主动参加才计一人。认领必须一减一增同事务。仅检查“先查空位再插入”是不合格实现。

## 2. 幂等和版本
幂等记录绑定 actor、operation、key、canonical payload hash、执行状态与 receipt。相同 payload 重放同结果；不同 payload 同 key 返回409。完成状态与业务事务一起提交。失败/未知效果不能删除幂等记录后重试。租户/活动过滤属于事务内鉴权，不只在入口查一次。重大变更后旧 accepted_version 不算新同意。

## 3. 候补状态转换
释放席位 → FIFO（joined_at，稳定ID打破同秒平局）取下一合格候补 → 创建唯一短期 offer并占位 → outbox。默认15分钟，但 `offer_expiry = min(now+15m,registration_deadline)`；不足5分钟不发新offer。确认与到期并发锁同活动+offer，数据库时间裁定，至多一方成功。通知失败不提前释放offer。过期worker重放、旧worker恢复均不能重新占位。

## 4. Outbox 与执行租约
业务更新和 outbox INSERT 在一个数据库事务提交。Worker 以有期限租约/递增 fencing token 认领，外部网络调用不持有业务长事务。消费者以 business_event_id 去重；投递at-least-once，不宣称网络exactly-once。数据库恢复后重新扫描未完成outbox，并通过幂等/核对避免重复副作用。过期worker的结果提交必须校验fence。

业务例行任务用数据库持久调度，不用 Codex Goal/Claude Loop。任务含event_id/version/recipient/authorization_version/due_at/action_type。执行前重读取消、用户退出、撤回授权与最新版本。

## 5. 未知外部效果
PROVIDER_ACCEPTED != DELIVERED != OPENED。超时后先写 UNKNOWN_REQUIRES_RECONCILIATION；有提供方查单则核对；不支持查单则人工/明确可安全重试政策，禁止无条件自动重发。关闭外部提醒仍保留小程序内消息与退出能力。Dead-letter 需原因、关联事件、重放权限和人工队列。

## 6. 成局与时间线
存 UTC时间点并保留活动 IANA time_zone。相对日期只在草稿阶段按活动地时区解析，向用户展示完整日期。调度用服务端时间，不信客户端。形成截止、报名截止、活动开始/结束的先后必须校验。达到最少人数、主办确认、场地依据、风险解除同时成立才能成局；临界下降标风险并按规则取消，不篡改历史门槛。开始后的问题进入事件处置，不追改历史规则。

## 7. 重大变更
锁 event/version → diff预览凭证验证 → 不可变新EventVersion → 暂停招募 → 原有效报名转RECONFIRM_REQUIRED、明确hold期限 → 旧offer/授权任务撤销或重新产生 → outbox。新版本确认前不计成局人数，不替用户接受费用/公开范围扩大。拒绝/超时无平台惩罚退出。非重大错字保留审计不滥用重新报名。

## 8. 故障试验
杀worker于外部调用前/后、事务提交后outbox消费前、租约到期后旧worker返回；100并发最后席位；offer确认/超时同一毫秒；reserve认领/到期；重复取消/重放；版本冲突；队列恢复；灾备重放。断言业务DB、不只HTTP/日志。对应127条验收中的并发、恢复、授权用例。
