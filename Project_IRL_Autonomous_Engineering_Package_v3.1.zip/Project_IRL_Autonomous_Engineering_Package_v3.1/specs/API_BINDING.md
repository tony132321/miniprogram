# API 适配与扩展规则

`openapi.json` 是从 PRD 提炼的设计契约，不是已有接口发现结果。目标 Agent 必须先读真实路由再形成 ADR；保持语义兼容，必要时增量映射，不强制替换现有框架。

## 重要语义
- 公开 GET 是按访问权限生成投影；没有合法邀请的访问者只见最小摘要，不因 OpenAPI security=[] 获得成员信息。
- `expected_version` 对已有资源为必填。创建新草稿无需旧版本；更新草稿必须传版本。发布阶段另做完整性校验，不能把允许不完整草稿的 schema 当发布 schema。
- 成局条件、时间先后、总容量、人民币分、主办参与、活动内角色与成年人准入均须服务端验证，JSON Schema 不能单独表达所有跨字段约束。
- confirmation/impact token 绑定 actor、资源版本、规范化 payload hash、动作、过期时间、一次性 nonce。Token 不能由 AI 自造，重放受幂等控制。
- 错误码最少：AUTH_REQUIRED、FORBIDDEN、RESOURCE_NOT_VISIBLE、VERSION_CONFLICT、CAPACITY_FULL、IDEMPOTENCY_PAYLOAD_MISMATCH、OFFER_EXPIRED、CONSENT_REVOKED、MODERATION_PENDING、DEPENDENCY_UNAVAILABLE、EFFECT_UNKNOWN。失败不得含用户隐私或堆栈。
- 分页采用游标，限定页大小，默认不返回全活动成员信息。登录码只在后端换取实际凭证；不可将 openid 当作身份密码。

## 子模块接口与页面联动
已显式纳入协办授权/撤回、成员最小投影、审批拒绝/移除、公告/问答/回答、离线补记/本人确认/争议、账单读取、屏蔽、隐私状态、后台分配/申诉复核/指标等路由草案。实际实现仍须把所有字段绑定真实schema和测试，不得仅依据接口数量宣布完成。`x-roles`只描述潜在角色，最终由单活动能力+归属+purpose鉴权；登录交换是无已登录身份的特殊入口，幂等使用短期设备会话与code摘要，不记录原始code。

## 提案默认值与产品决定
4–12 人、室内羽毛球、INVITE_ONLY 是首版模板假设，不是平台限制或已确认最终商业决定。经用户改变模板时记录 ADR/需求变更及受影响用例；不可静默将公开匹配放进 R1。
