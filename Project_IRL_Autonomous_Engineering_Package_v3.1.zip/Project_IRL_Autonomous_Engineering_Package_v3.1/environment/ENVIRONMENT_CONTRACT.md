# 环境与依赖能力绑定

本包不是已启动应用。目标Agent读取真实仓库AGENTS/CLAUDE/lockfile/CI后，将真实命令argv、cwd、来源文件、版本写入COMMAND_BINDINGS.json；不能用猜测的npm test替代发现。空仓库才使用模块化单体、原生小程序+TypeScript、常规Web后台、关系DB、持久队列与适配器的PRD建议架构，先落ADR。框架版本通过执行环境可访问的一手文档核验，不在本包伪装锁定最新版本。

环境分为local synthetic / integration test / approved candidate / controlled pilot / production。不同DB/队列namespace/对象存储/日志/凭证/通知收件人；git worktree不隔离这些资源。每个worker实例有隔离端口与数据库测试命名空间。

无AppID或真实设备可以实现本地确定性域和标明stub的接口测试，但真实微信/真机门保持NOT_RUN。若个人电脑平台不可运行DevTools，转交批准的macOS/Windows runner；不能用Web仿真截图替代小程序真机。预览/上传需真实AppID、签名身份和单独的候选环境授权。

只将变量名加入.env.example，秘密进入目标平台secret manager，不放prompt/文件包/日志。安装依赖前检查锁文件与脚本；不执行不明来源npx或curl|sh。外部API、网络费用和供应商条款受授权范围限制。
