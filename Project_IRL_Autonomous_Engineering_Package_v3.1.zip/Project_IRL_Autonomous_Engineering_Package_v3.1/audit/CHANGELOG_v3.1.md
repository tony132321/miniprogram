# v3.1 修订摘要

2026-09-25，包版本升级，不改变PRD版本或产品release号。

- 原始PRD/Skill原封保留；同父工单/35任务身份。
- 8验收定义→127条规格；修复35个未定义引用；RQ18进入明确范围。
- 32需求条目、12页面、导航和状态、57 API操作/45 schema。
- 新Graph reviewed-batch契约蓝图、正式发布门先退役错误admission再授权设计。
- Codex/Claude原生Goal；Claude有限只读Loop；完整首次授权和恢复路径。
- 状态与规格分离；CAS/锁/候选hash/receipt/requiredCI集合/真实提供方 gate。
- 62项工具测试与故障注入证据；初始UAT拒绝。
- 全部真实产品/平台/部署能力仍待目标环境执行，不用包PASS冒充软件完成。
