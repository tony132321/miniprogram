# 外部工具核验与限制（2026-09-25）

以下是本次外部核验，不是PRD原文事实，也不是对用户已安装版本的探测。运行前仍须核查当前目标surface/版本/权限。

|来源|核验到的内容|地址|
|---|---|---|
|OpenAI Codex developer commands，官方页面|/goal、目标管理、目标<=4000字符；按surface可用性核查|https://developers.openai.com/codex/cli/slash-commands |
|Claude Code Goal官方文档|/goal、持久目标、评价器看会话但不独立运行工具；权限不自动扩大|https://code.claude.com/docs/en/goal |
|Claude Code Scheduled tasks官方文档|/loop周期任务、实际取消/恢复/到期规则；不当作永远在线服务|https://code.claude.com/docs/en/scheduled-tasks |
|Graph Engineering作者仓库|规范是Skill与Graph契约，不是独立执行runtime；有限循环与风险分层|https://github.com/luxiaolei/graph-engineering |
|Graph Skill|schema/profile、节点/边/路由/Review/权限要求|https://github.com/luxiaolei/graph-engineering/blob/main/skills/graph-engineering/SKILL.md |
|reviewed-batch模板|本包Graph格式依据；由GitHub connector读取，blob SHA 778839bd3cca89f2e2456f41ce157c834bda748e|https://github.com/luxiaolei/graph-engineering/blob/main/skills/graph-engineering/assets/templates/graph-reviewed-batch.md |
|上游validator源码|结构验证不能证明语义或业务完成|https://github.com/luxiaolei/graph-engineering/blob/main/skills/graph-engineering/scripts/validate_project_graph.py |

## 未完成的外部核验
容器git下载和raw下载失败，因此**上游Graph validator未执行**。本包脚本只是自有结构/引用/证据合同检查，不可把其PASS写为Graph官方validator PASS。未安装任何全局Skill，未读取用户真实Project IRL仓库、微信后台、类目、证书、供应商或真机。现有PRD中的法律/平台核验边界保持不变；本次不宣称重新完成法务审查。

## 两种不同检查
validation目录记录本包文件/脚本的本地检查；evidence/product目录留给目标Agent实际产品验收。只有后者的真实身份、候选和权威回读可支持产品状态。所有提案schema/颜色/预算/路由与库版本，必须在真实repo内适配和验证。
